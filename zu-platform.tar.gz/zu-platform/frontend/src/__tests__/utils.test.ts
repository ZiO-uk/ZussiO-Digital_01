import { formatCurrency, formatDate, formatBytes, truncate, slugify, getRiskLevel } from '../../src/lib/utils';

describe('formatCurrency', () => {
  it('formats GBP correctly', () => {
    expect(formatCurrency(1000)).toBe('£1,000');
    expect(formatCurrency(99.99)).toBe('£100'); // rounds to 0 decimal places
    expect(formatCurrency(0)).toBe('£0');
  });

  it('handles different currencies', () => {
    const eur = formatCurrency(500, 'EUR');
    expect(eur).toContain('500');
  });
});

describe('formatBytes', () => {
  it('formats bytes correctly', () => {
    expect(formatBytes(0)).toBe('0 B');
    expect(formatBytes(1024)).toBe('1 KB');
    expect(formatBytes(1048576)).toBe('1 MB');
    expect(formatBytes(1073741824)).toBe('1 GB');
    expect(formatBytes(5368709120)).toBe('5 GB');
  });

  it('handles fractional sizes', () => {
    expect(formatBytes(1536)).toBe('1.5 KB');
  });
});

describe('truncate', () => {
  it('does not truncate short strings', () => {
    expect(truncate('Hello', 10)).toBe('Hello');
  });

  it('truncates long strings with ellipsis', () => {
    const result = truncate('This is a very long string', 10);
    expect(result).toBe('This is a …');
    expect(result.length).toBeLessThanOrEqual(11);
  });

  it('handles exact length strings', () => {
    expect(truncate('Hello', 5)).toBe('Hello');
  });
});

describe('slugify', () => {
  it('converts spaces to hyphens', () => {
    expect(slugify('Hello World')).toBe('hello-world');
  });

  it('removes special characters', () => {
    expect(slugify('Acme Ltd & Co!')).toBe('acme-ltd-co');
  });

  it('handles already-slugified input', () => {
    expect(slugify('acme-ltd')).toBe('acme-ltd');
  });

  it('trims leading/trailing hyphens', () => {
    expect(slugify('  Hello World  ')).toBe('hello-world');
  });

  it('collapses multiple spaces', () => {
    expect(slugify('Hello   World')).toBe('hello-world');
  });
});

describe('getRiskLevel', () => {
  it('returns critical for score >= 20', () => {
    expect(getRiskLevel(20).label).toBe('Critical');
    expect(getRiskLevel(25).label).toBe('Critical');
  });

  it('returns high for score 15-19', () => {
    expect(getRiskLevel(15).label).toBe('High');
    expect(getRiskLevel(19).label).toBe('High');
  });

  it('returns medium for score 8-14', () => {
    expect(getRiskLevel(8).label).toBe('Medium');
    expect(getRiskLevel(14).label).toBe('Medium');
  });

  it('returns low for score < 8', () => {
    expect(getRiskLevel(1).label).toBe('Low');
    expect(getRiskLevel(7).label).toBe('Low');
  });

  it('returns appropriate colour classes', () => {
    expect(getRiskLevel(25).colour).toContain('red');
    expect(getRiskLevel(16).colour).toContain('orange');
    expect(getRiskLevel(10).colour).toContain('amber');
    expect(getRiskLevel(2).colour).toContain('emerald');
  });
});
