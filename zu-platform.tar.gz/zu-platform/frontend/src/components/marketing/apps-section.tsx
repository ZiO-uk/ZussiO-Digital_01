import Link from 'next/link';
import { Shield, CreditCard, FileText, Users, BarChart2, Briefcase, DollarSign, Package, Headphones, GraduationCap, ArrowRight, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

const ACTIVE_APPS = [
  {
    slug: 'isms',
    name: 'ISMS Trustee',
    tagline: 'Information Security Management',
    description:
      'Manage ISO 27001, Cyber Essentials, and GDPR compliance. Risk registers, control libraries, policy management, and audit tracking in one place.',
    icon: Shield,
    colour: 'bg-zu-500',
    textColour: 'text-zu-600 dark:text-zu-400',
    badgeBg: 'bg-zu-50 text-zu-700 dark:bg-zu-950/50 dark:text-zu-300',
    plan: 'Gold',
    href: '/apps/isms',
  },
  {
    slug: 'zucards',
    name: 'ZuCards',
    tagline: 'Group eCard Platform',
    description:
      'Create beautiful group greeting cards for birthdays, work anniversaries, farewells and more. Collect messages from the whole team and deliver with a single click.',
    icon: CreditCard,
    colour: 'bg-accent-500',
    textColour: 'text-accent-600 dark:text-accent-400',
    badgeBg: 'bg-accent-50 text-accent-700 dark:bg-accent-950/50 dark:text-accent-300',
    plan: 'Free',
    href: '/apps/zucards',
  },
  {
    slug: 'zudoc',
    name: 'ZuDoc',
    tagline: 'Document Management & e-Signatures',
    description:
      'Rich document editor, secure storage, version history, and legally-compliant e-signatures. From NDAs to tenancy agreements, handled end to end.',
    icon: FileText,
    colour: 'bg-emerald-500',
    textColour: 'text-emerald-600 dark:text-emerald-400',
    badgeBg: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-300',
    plan: 'Free',
    href: '/apps/zudoc',
  },
];

const COMING_SOON_APPS = [
  { name: 'CRM', icon: Users },
  { name: 'HR Management', icon: Briefcase },
  { name: 'Projects', icon: BarChart2 },
  { name: 'Finance', icon: DollarSign },
  { name: 'Asset Management', icon: Package },
  { name: 'Service Desk', icon: Headphones },
  { name: 'Learning Management', icon: GraduationCap },
];

export function AppsSection() {
  return (
    <section id="applications" className="zu-section bg-muted/30">
      <div className="zu-container">
        {/* Header */}
        <div className="mx-auto mb-16 max-w-2xl text-center">
          <Badge variant="secondary" className="mb-4 rounded-full px-4 py-1">
            Applications
          </Badge>
          <h2 className="font-display text-4xl font-bold tracking-tight sm:text-5xl">
            Purpose-built tools for{' '}
            <span className="zu-gradient-text">every team</span>
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Start with what you need today. Every application shares a common
            platform so adding new capabilities takes seconds, not months.
          </p>
        </div>

        {/* Active Apps */}
        <div className="grid gap-8 md:grid-cols-3">
          {ACTIVE_APPS.map((app) => {
            const Icon = app.icon;
            return (
              <div
                key={app.slug}
                className="group rounded-2xl border bg-card p-6 shadow-zu-sm transition-all hover:shadow-zu-lg hover:-translate-y-1"
              >
                <div className={cn('mb-4 inline-flex h-12 w-12 items-center justify-center rounded-xl text-white', app.colour)}>
                  <Icon size={22} />
                </div>
                <div className="mb-3 flex items-center justify-between">
                  <h3 className="font-display text-xl font-bold">{app.name}</h3>
                  <span className={cn('app-badge text-xs font-medium rounded-full px-3 py-1', app.badgeBg)}>
                    {app.plan}
                  </span>
                </div>
                <p className={cn('mb-1 text-sm font-medium', app.textColour)}>
                  {app.tagline}
                </p>
                <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
                  {app.description}
                </p>
                <div className="mt-6">
                  <Button
                    variant="outline"
                    size="sm"
                    asChild
                    className="w-full group-hover:border-primary group-hover:text-primary transition-colors"
                  >
                    <Link href={app.href}>
                      Learn More
                      <ArrowRight size={14} className="ml-2 transition-transform group-hover:translate-x-1" />
                    </Link>
                  </Button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Coming Soon Apps */}
        <div className="mt-12">
          <p className="mb-6 text-center text-sm font-medium text-muted-foreground uppercase tracking-widest">
            Coming Soon
          </p>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4 lg:grid-cols-7">
            {COMING_SOON_APPS.map((app) => {
              const Icon = app.icon;
              return (
                <div
                  key={app.name}
                  className="flex flex-col items-center gap-3 rounded-xl border border-dashed bg-card/50 px-4 py-5 opacity-50 cursor-not-allowed"
                  aria-disabled="true"
                >
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted">
                    <Icon size={18} className="text-muted-foreground" />
                  </div>
                  <span className="text-center text-xs font-medium text-muted-foreground">
                    {app.name}
                  </span>
                  <span className="flex items-center gap-1 rounded-full bg-muted px-2 py-0.5 text-xs text-muted-foreground">
                    <Clock size={10} />
                    Soon
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
