'use client';

import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { SignedIn, SignedOut, UserButton } from '@clerk/nextjs';
import { Menu, X, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { ModeToggle } from '@/components/layout/mode-toggle';

const navLinks = [
  { href: '/',               label: 'Home' },
  { href: '/apps',           label: 'Applications' },
  { href: '/pricing',        label: 'Pricing' },
  { href: '/about',          label: 'About Us' },
  { href: '/contact',        label: 'Contact' },
];

export function MarketingNav() {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/80 backdrop-blur-sm">
      <nav className="zu-container flex h-16 items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2.5 font-display font-bold text-xl">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg zu-gradient-bg text-white">
            <Zap size={16} />
          </div>
          <span className="zu-gradient-text">Zu Platform</span>
        </Link>

        {/* Desktop links */}
        <ul className="hidden items-center gap-1 md:flex">
          {navLinks.map((link) => (
            <li key={link.href}>
              <Link
                href={link.href}
                className={cn(
                  'rounded-md px-3 py-2 text-sm font-medium transition-colors hover:bg-accent hover:text-accent-foreground',
                  pathname === link.href
                    ? 'text-foreground'
                    : 'text-muted-foreground'
                )}
              >
                {link.label}
              </Link>
            </li>
          ))}
        </ul>

        {/* CTA */}
        <div className="hidden items-center gap-3 md:flex">
          <ModeToggle />
          <SignedOut>
            <Button variant="ghost" size="sm" asChild>
              <Link href="/sign-in">Log in</Link>
            </Button>
            <Button size="sm" asChild className="zu-gradient-bg text-white hover:opacity-90">
              <Link href="/sign-up">Start Free</Link>
            </Button>
          </SignedOut>
          <SignedIn>
            <Button variant="ghost" size="sm" asChild>
              <Link href="/dashboard">Dashboard</Link>
            </Button>
            <UserButton afterSignOutUrl="/" />
          </SignedIn>
        </div>

        {/* Mobile hamburger */}
        <button
          className="md:hidden"
          onClick={() => setOpen(!open)}
          aria-label="Toggle menu"
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </nav>

      {/* Mobile menu */}
      {open && (
        <div className="border-t bg-background md:hidden">
          <div className="zu-container py-4 flex flex-col gap-1">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setOpen(false)}
                className={cn(
                  'rounded-md px-3 py-2 text-sm font-medium transition-colors hover:bg-accent',
                  pathname === link.href ? 'text-foreground' : 'text-muted-foreground'
                )}
              >
                {link.label}
              </Link>
            ))}
            <div className="mt-3 flex flex-col gap-2 pt-3 border-t">
              <SignedOut>
                <Button variant="outline" size="sm" asChild>
                  <Link href="/sign-in" onClick={() => setOpen(false)}>Log in</Link>
                </Button>
                <Button size="sm" asChild className="zu-gradient-bg text-white">
                  <Link href="/sign-up" onClick={() => setOpen(false)}>Start Free</Link>
                </Button>
              </SignedOut>
              <SignedIn>
                <Button variant="ghost" size="sm" asChild>
                  <Link href="/dashboard" onClick={() => setOpen(false)}>Dashboard</Link>
                </Button>
              </SignedIn>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
