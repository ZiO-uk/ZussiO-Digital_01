import Link from 'next/link';
import { Zap } from 'lucide-react';
import { Separator } from '@/components/ui/separator';

const FOOTER_LINKS = {
  Platform: [
    { label: 'Applications', href: '/apps' },
    { label: 'Pricing',      href: '/pricing' },
    { label: 'About Us',     href: '/about' },
    { label: 'Contact',      href: '/contact' },
  ],
  Applications: [
    { label: 'ISMS Trustee', href: '/apps/isms' },
    { label: 'ZuCards',      href: '/apps/zucards' },
    { label: 'ZuDoc',        href: '/apps/zudoc' },
  ],
  Legal: [
    { label: 'Privacy Policy',    href: '/privacy' },
    { label: 'Terms of Service',  href: '/terms' },
    { label: 'Cookie Policy',     href: '/cookies' },
    { label: 'Security',          href: '/security' },
  ],
};

export function MarketingFooter() {
  return (
    <footer className="border-t bg-card">
      <div className="zu-container py-12">
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {/* Brand */}
          <div>
            <Link href="/" className="flex items-center gap-2.5 font-display font-bold text-lg mb-4">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg zu-gradient-bg text-white">
                <Zap size={14} />
              </div>
              <span className="zu-gradient-text">Zu Platform</span>
            </Link>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Enterprise-grade modular SaaS ecosystem for modern businesses.
              One platform. Multiple solutions.
            </p>
            <p className="mt-4 text-xs text-muted-foreground">
              🇬🇧 Made in the United Kingdom
            </p>
          </div>

          {/* Link columns */}
          {Object.entries(FOOTER_LINKS).map(([heading, links]) => (
            <div key={heading}>
              <h3 className="mb-4 text-sm font-semibold">{heading}</h3>
              <ul className="space-y-2.5">
                {links.map((link) => (
                  <li key={link.href}>
                    <Link
                      href={link.href}
                      className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <Separator className="my-8" />

        <div className="flex flex-col items-center gap-2 sm:flex-row sm:justify-between">
          <p className="text-xs text-muted-foreground">
            © {new Date().getFullYear()} Zu Platform Ltd. All rights reserved.
          </p>
          <p className="text-xs text-muted-foreground">
            Registered in England & Wales
          </p>
        </div>
      </div>
    </footer>
  );
}
