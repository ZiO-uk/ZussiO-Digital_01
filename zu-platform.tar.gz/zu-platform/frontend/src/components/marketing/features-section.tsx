import { Shield, Layers, TrendingUp, Cloud, Users2, Award } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

const FEATURES = [
  {
    icon: Layers,
    title: 'Unified Platform',
    description:
      'One login, one dashboard, one bill. All your business tools share authentication, data, and permissions without duplication.',
    colour: 'text-zu-500 bg-zu-50 dark:bg-zu-950/50',
  },
  {
    icon: Shield,
    title: 'Secure Architecture',
    description:
      'Multi-tenant data isolation, row-level security, MFA-ready auth, OWASP best practices, and audit logging baked in from day one.',
    colour: 'text-emerald-500 bg-emerald-50 dark:bg-emerald-950/50',
  },
  {
    icon: TrendingUp,
    title: 'Unlimited Growth',
    description:
      'The platform module registry means adding a new application never touches existing code. Scale your stack as you scale your business.',
    colour: 'text-accent-500 bg-accent-50 dark:bg-accent-950/50',
  },
  {
    icon: Cloud,
    title: 'Cloud Hosted',
    description:
      'Fully managed infrastructure, 99.9% uptime SLA, automatic backups, and global CDN delivery so you never worry about servers.',
    colour: 'text-sky-500 bg-sky-50 dark:bg-sky-950/50',
  },
  {
    icon: Users2,
    title: 'Collaboration Tools',
    description:
      'Real-time contribution flows for cards, shared document editing, multi-signatory e-signatures, and team-wide policy acknowledgements.',
    colour: 'text-violet-500 bg-violet-50 dark:bg-violet-950/50',
  },
  {
    icon: Award,
    title: 'Enterprise Ready',
    description:
      'SSO-ready, WCAG 2.1 AA accessible, GDPR compliant, role-based access control, and white-labelling options for larger organisations.',
    colour: 'text-rose-500 bg-rose-50 dark:bg-rose-950/50',
  },
];

export function FeaturesSection() {
  return (
    <section className="zu-section">
      <div className="zu-container">
        <div className="mx-auto mb-16 max-w-2xl text-center">
          <Badge variant="secondary" className="mb-4 rounded-full px-4 py-1">
            Platform Features
          </Badge>
          <h2 className="font-display text-4xl font-bold tracking-tight sm:text-5xl">
            Built for businesses that{' '}
            <span className="zu-gradient-text">take security seriously</span>
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Every decision in Zu Platform's architecture starts with security,
            compliance, and scalability — then works outward.
          </p>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((feature) => {
            const Icon = feature.icon;
            return (
              <div
                key={feature.title}
                className="rounded-2xl border bg-card p-6 transition-shadow hover:shadow-zu-md"
              >
                <div className={`mb-4 inline-flex h-11 w-11 items-center justify-center rounded-xl ${feature.colour}`}>
                  <Icon size={20} />
                </div>
                <h3 className="mb-2 font-display text-lg font-bold">{feature.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {feature.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
