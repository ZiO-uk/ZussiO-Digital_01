import Link from 'next/link';
import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function CtaSection() {
  return (
    <section className="zu-section">
      <div className="zu-container">
        <div className="relative overflow-hidden rounded-3xl zu-gradient-bg px-8 py-16 text-center sm:px-16">
          <div aria-hidden className="pointer-events-none absolute inset-0">
            <div className="absolute top-0 left-1/4 h-64 w-64 rounded-full bg-white/10 blur-3xl" />
            <div className="absolute bottom-0 right-1/4 h-64 w-64 rounded-full bg-white/10 blur-3xl" />
          </div>
          <div className="relative">
            <h2 className="font-display text-3xl font-bold text-white sm:text-4xl lg:text-5xl">
              Ready to simplify your operations?
            </h2>
            <p className="mx-auto mt-4 max-w-xl text-lg text-white/80">
              Start with the free plan today. No credit card required. Upgrade
              when your team needs more.
            </p>
            <div className="mt-8 flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
              <Button
                size="lg"
                asChild
                className="bg-white text-zu-600 hover:bg-white/90 shadow-lg px-8 h-12 text-base font-semibold"
              >
                <Link href="/sign-up">
                  Get Started Free
                  <ArrowRight size={18} className="ml-2" />
                </Link>
              </Button>
              <Button
                size="lg"
                variant="ghost"
                asChild
                className="text-white hover:bg-white/10 border border-white/30 px-8 h-12 text-base"
              >
                <Link href="/contact">Talk to Sales</Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
