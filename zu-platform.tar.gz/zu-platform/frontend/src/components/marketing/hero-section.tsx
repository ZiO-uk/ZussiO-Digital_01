import Link from 'next/link';
import { ArrowRight, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

export function HeroSection() {
  return (
    <section className="zu-hero-section">
      {/* Gradient background blobs */}
      <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 left-1/2 -translate-x-1/2 h-[600px] w-[600px] rounded-full bg-zu-500/10 blur-3xl" />
        <div className="absolute top-20 -right-20 h-[400px] w-[400px] rounded-full bg-purple-500/10 blur-3xl" />
        <div className="absolute bottom-0 -left-20 h-[300px] w-[300px] rounded-full bg-accent-500/10 blur-3xl" />
      </div>

      <div className="zu-container relative">
        <div className="mx-auto max-w-4xl text-center">
          {/* Eyebrow badge */}
          <div className="mb-6 inline-flex items-center gap-2">
            <Badge variant="secondary" className="px-4 py-1.5 text-sm font-medium rounded-full border-zu-200 bg-zu-50 text-zu-700 dark:bg-zu-950 dark:text-zu-300 dark:border-zu-800">
              <Sparkles size={14} className="mr-1" />
              Enterprise SaaS Platform
            </Badge>
          </div>

          <h1 className="font-display text-5xl font-extrabold leading-tight tracking-tight sm:text-6xl lg:text-7xl">
            One Platform.{' '}
            <span className="zu-gradient-text">Multiple Business</span>{' '}
            Solutions.
          </h1>

          <p className="mt-6 text-xl text-muted-foreground leading-relaxed max-w-2xl mx-auto">
            Zu Platform brings compliance management, team cards, and intelligent
            document handling together under one unified, enterprise-grade
            ecosystem — so your teams work smarter, not harder.
          </p>

          <div className="mt-10 flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
            <Button
              size="lg"
              asChild
              className="zu-gradient-bg text-white hover:opacity-90 shadow-zu-md px-8 h-12 text-base"
            >
              <Link href="/sign-up">
                Start Free Today
                <ArrowRight size={18} className="ml-2" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild className="px-8 h-12 text-base">
              <Link href="/apps">View Applications</Link>
            </Button>
          </div>

          {/* Social proof strip */}
          <p className="mt-8 text-sm text-muted-foreground">
            Trusted by security-conscious teams ·{' '}
            <span className="font-medium text-foreground">Free plan available</span>{' '}
            · No credit card required
          </p>
        </div>

        {/* Dashboard preview mockup */}
        <div className="mt-16 mx-auto max-w-5xl">
          <div className="relative rounded-2xl border bg-card shadow-zu-xl overflow-hidden">
            <div className="flex items-center gap-2 border-b px-4 py-3 bg-muted/50">
              <div className="h-3 w-3 rounded-full bg-red-400" />
              <div className="h-3 w-3 rounded-full bg-amber-400" />
              <div className="h-3 w-3 rounded-full bg-emerald-400" />
              <div className="ml-2 flex-1 rounded bg-background px-3 py-1 text-xs text-muted-foreground">
                app.zuplatform.com/dashboard
              </div>
            </div>
            <div className="grid grid-cols-12 h-[380px]">
              {/* Sidebar */}
              <aside className="col-span-2 border-r p-3 space-y-1 bg-card hidden sm:block">
                {['Dashboard', 'Applications', 'ISMS', 'ZuCards', 'ZuDoc', 'Billing', 'Settings'].map((item, i) => (
                  <div
                    key={item}
                    className={`rounded-md px-2 py-1.5 text-xs font-medium ${
                      i === 0 ? 'bg-zu-500/10 text-zu-600' : 'text-muted-foreground'
                    }`}
                  >
                    {item}
                  </div>
                ))}
              </aside>
              {/* Main content */}
              <div className="col-span-12 sm:col-span-10 p-6 bg-muted/20">
                <div className="mb-4">
                  <div className="h-4 w-32 rounded bg-muted animate-pulse" />
                  <div className="h-3 w-20 rounded bg-muted mt-2 animate-pulse" />
                </div>
                <div className="grid grid-cols-3 gap-4 mb-4">
                  {['System Health', 'Active Users', 'MRR'].map((label) => (
                    <div key={label} className="rounded-lg border bg-card p-4">
                      <div className="h-3 w-16 rounded bg-muted mb-2" />
                      <div className="h-6 w-12 rounded bg-zu-500/20" />
                    </div>
                  ))}
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="rounded-lg border bg-card p-4 h-28" />
                  <div className="rounded-lg border bg-card p-4 h-28" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
