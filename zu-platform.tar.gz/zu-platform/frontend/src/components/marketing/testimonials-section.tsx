import { Quote } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

const TESTIMONIALS = [
  {
    quote:
      'ISMS Trustee replaced three separate tools we were using for ISO 27001 preparation. Having everything in one place, linked to our wider platform, has genuinely saved us weeks.',
    name: 'Sarah Mitchell',
    role: 'Head of Information Security',
    company: 'Global Security Partners',
    initials: 'SM',
    colour: 'bg-zu-500',
  },
  {
    quote:
      'ZuCards has completely changed how we celebrate team milestones. The card went around 47 people in 20 minutes — and the recipient was genuinely moved. Simple, but it matters.',
    name: 'James Thornton',
    role: 'HR Director',
    company: 'Acme Ltd',
    initials: 'JT',
    colour: 'bg-accent-500',
  },
  {
    quote:
      'ZuDoc streamlined our tenancy agreement process from days to hours. The e-signature audit trail alone has saved us significant legal exposure.',
    name: 'Priya Sharma',
    role: 'Operations Manager',
    company: 'Sheffield Housing Group',
    initials: 'PS',
    colour: 'bg-emerald-500',
  },
];

export function TestimonialsSection() {
  return (
    <section className="zu-section bg-muted/30">
      <div className="zu-container">
        <div className="mx-auto mb-16 max-w-2xl text-center">
          <Badge variant="secondary" className="mb-4 rounded-full px-4 py-1">
            What teams are saying
          </Badge>
          <h2 className="font-display text-4xl font-bold tracking-tight sm:text-5xl">
            Real outcomes for{' '}
            <span className="zu-gradient-text">real businesses</span>
          </h2>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          {TESTIMONIALS.map((t) => (
            <div
              key={t.name}
              className="rounded-2xl border bg-card p-6 shadow-zu-sm flex flex-col"
            >
              <Quote size={28} className="mb-4 text-zu-300" />
              <p className="flex-1 text-sm leading-relaxed text-muted-foreground italic">
                "{t.quote}"
              </p>
              <div className="mt-6 flex items-center gap-3">
                <Avatar className="h-10 w-10">
                  <AvatarFallback className={`text-white text-sm font-bold ${t.colour}`}>
                    {t.initials}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="text-sm font-semibold">{t.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {t.role} · {t.company}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
