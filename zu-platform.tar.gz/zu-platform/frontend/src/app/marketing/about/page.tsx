import { Metadata } from 'next';
import { Badge } from '@/components/ui/badge';
import { Shield, Lightbulb, Layers, Heart, TrendingUp, Target, Zap } from 'lucide-react';

export const metadata: Metadata = { title: 'About Us' };

const VALUES = [
  { icon: Shield,     name: 'Security',          desc: 'We treat security as a first-class feature, not an afterthought. Every architectural decision begins with "is this safe?"' },
  { icon: Lightbulb, name: 'Innovation',         desc: 'We build tools that make genuinely hard problems feel simple. If something takes days elsewhere, we want it to take minutes here.' },
  { icon: Layers,    name: 'Simplicity',         desc: 'Complexity is the enemy of adoption. Every interface we ship is reviewed against the question: could someone use this without training?' },
  { icon: Heart,     name: 'Trust',              desc: 'Our customers put their compliance posture, documents, and team moments in our hands. We earn that trust every day.' },
  { icon: TrendingUp,name: 'Customer Success',   desc: 'We succeed when our customers succeed. Support, documentation, and onboarding are not afterthoughts.' },
];

const ROADMAP = [
  { quarter: 'Q1 2024', status: 'done',    label: 'ISMS Trustee v1 · ZuCards · ZuDoc · Free plan launch' },
  { quarter: 'Q2 2024', status: 'done',    label: 'E-signature audit log · Policy acknowledgements · Gold plan' },
  { quarter: 'Q3 2024', status: 'active',  label: 'Silver plan · Enhanced risk matrix · Mobile app' },
  { quarter: 'Q4 2024', status: 'planned', label: 'CRM module · API marketplace · White-label offering' },
  { quarter: 'Q1 2025', status: 'planned', label: 'HR module · Finance module · ISO 27002 controls library' },
  { quarter: 'Q2 2025', status: 'planned', label: 'Projects module · Service Desk · Learning Management' },
];

export default function AboutPage() {
  return (
    <div>
      {/* Hero */}
      <section className="zu-section border-b">
        <div className="zu-container">
          <div className="mx-auto max-w-3xl text-center">
            <Badge variant="secondary" className="mb-4 rounded-full px-4 py-1">About Us</Badge>
            <h1 className="font-display text-5xl font-extrabold tracking-tight sm:text-6xl">
              Built for businesses that{' '}
              <span className="zu-gradient-text">can't afford to cut corners</span>
            </h1>
            <p className="mt-6 text-xl text-muted-foreground leading-relaxed">
              Zu Platform was created by a team that had lived through the pain of stitching
              together compliance tools, document systems, and communication platforms from
              half a dozen separate vendors. We built the platform we wished existed.
            </p>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="zu-section">
        <div className="zu-container">
          <div className="grid gap-8 md:grid-cols-2">
            <div className="rounded-2xl border bg-card p-8">
              <div className="mb-4 inline-flex h-10 w-10 items-center justify-center rounded-xl bg-zu-50 dark:bg-zu-950/30">
                <Target size={20} className="text-zu-500" />
              </div>
              <h2 className="font-display text-2xl font-bold mb-3">Our Mission</h2>
              <p className="text-muted-foreground leading-relaxed">
                Help businesses of every size simplify their operations through modular,
                enterprise-grade software — without the enterprise price tag or the
                enterprise implementation timeline.
              </p>
            </div>
            <div className="rounded-2xl border bg-card p-8">
              <div className="mb-4 inline-flex h-10 w-10 items-center justify-center rounded-xl bg-accent-50 dark:bg-accent-950/30">
                <Zap size={20} className="text-accent-500" />
              </div>
              <h2 className="font-display text-2xl font-bold mb-3">Our Vision</h2>
              <p className="text-muted-foreground leading-relaxed">
                To become the leading modular business operating system for UK and European
                businesses — where every tool a company needs is a single subscription away,
                sharing one login, one data layer, and one support team.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="zu-section bg-muted/30">
        <div className="zu-container">
          <div className="mx-auto mb-12 max-w-2xl text-center">
            <h2 className="font-display text-4xl font-bold tracking-tight">
              What we stand for
            </h2>
          </div>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {VALUES.map((v) => {
              const Icon = v.icon;
              return (
                <div key={v.name} className="rounded-xl border bg-card p-6">
                  <Icon size={22} className="mb-3 text-zu-500" />
                  <h3 className="font-display text-lg font-bold mb-2">{v.name}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{v.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Roadmap */}
      <section className="zu-section">
        <div className="zu-container">
          <div className="mx-auto mb-12 max-w-2xl text-center">
            <h2 className="font-display text-4xl font-bold tracking-tight">Platform Roadmap</h2>
            <p className="mt-4 text-lg text-muted-foreground">
              Where we've been and where we're going.
            </p>
          </div>
          <div className="mx-auto max-w-2xl space-y-0">
            {ROADMAP.map((item, i) => (
              <div key={i} className="flex gap-6">
                <div className="flex flex-col items-center">
                  <div className={`mt-1 h-4 w-4 shrink-0 rounded-full border-2 ${
                    item.status === 'done'    ? 'bg-zu-500 border-zu-500' :
                    item.status === 'active'  ? 'bg-white border-zu-500 dark:bg-background' :
                    'bg-muted border-border'
                  }`} />
                  {i < ROADMAP.length - 1 && (
                    <div className={`w-0.5 flex-1 my-1 ${
                      item.status === 'done' ? 'bg-zu-500' : 'bg-border'
                    }`} />
                  )}
                </div>
                <div className="pb-6">
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">
                    {item.quarter}
                    {item.status === 'active' && (
                      <span className="ml-2 rounded-full bg-zu-100 text-zu-700 px-2 py-0.5 text-xs dark:bg-zu-950 dark:text-zu-400">
                        In progress
                      </span>
                    )}
                  </p>
                  <p className={`mt-1 text-sm ${
                    item.status === 'done' ? 'text-foreground' : 'text-muted-foreground'
                  }`}>{item.label}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
