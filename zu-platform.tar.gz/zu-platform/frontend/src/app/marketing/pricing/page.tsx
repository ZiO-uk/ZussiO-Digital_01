import { Metadata } from 'next';
import { Check, X, Zap, Bell } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import Link from 'next/link';
import { cn } from '@/lib/utils';

export const metadata: Metadata = { title: 'Pricing' };

const PLANS = [
  {
    name: 'Free',
    price: '£0',
    period: 'per month',
    description: 'Get started with the essentials. No card required.',
    badge: null,
    badgeClass: '',
    highlighted: false,
    cta: 'Start Free',
    ctaHref: '/sign-up',
    ctaVariant: 'outline' as const,
    features: [
      { label: 'ZuCards – group eCards',          included: true },
      { label: 'ZuDoc – document management',      included: true },
      { label: 'Unlimited cards & documents',      included: true },
      { label: 'Up to 10 users',                   included: true },
      { label: '5 GB storage',                     included: true },
      { label: 'Community support',                included: true },
      { label: 'E-signature requests',             included: true },
      { label: 'ISMS Trustee',                     included: false },
      { label: 'Compliance reporting',             included: false },
      { label: 'Priority support',                 included: false },
    ],
  },
  {
    name: 'Silver',
    price: 'Coming Soon',
    period: '',
    description:
      'The Silver tier is under development. Register your interest and be the first to know.',
    badge: 'Coming Soon',
    badgeClass: 'bg-gray-100 text-gray-600',
    highlighted: false,
    cta: 'Notify Me',
    ctaHref: '/contact?notify=silver',
    ctaVariant: 'outline' as const,
    features: [
      { label: 'Everything in Free',               included: true },
      { label: 'Expanded user limits',             included: true },
      { label: 'Increased storage',                included: true },
      { label: 'Additional applications',          included: true },
      { label: 'Email support',                    included: true },
      { label: 'ISMS Trustee',                     included: false },
      { label: 'Priority support',                 included: false },
    ],
  },
  {
    name: 'Gold',
    price: 'Custom',
    period: 'contact for pricing',
    description:
      'For compliance-focused organisations that need the full ISMS Trustee suite.',
    badge: 'Enterprise',
    badgeClass: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300',
    highlighted: true,
    cta: 'Contact Sales',
    ctaHref: '/contact?plan=gold',
    ctaVariant: 'default' as const,
    features: [
      { label: 'Everything in Silver',             included: true },
      { label: 'ISMS Trustee',                     included: true },
      { label: 'ISO 27001 framework',              included: true },
      { label: 'Cyber Essentials framework',       included: true },
      { label: 'GDPR compliance tools',            included: true },
      { label: 'Risk register & matrix',           included: true },
      { label: 'Audit management',                 included: true },
      { label: 'Compliance reporting',             included: true },
      { label: 'Unlimited users',                  included: true },
      { label: 'Priority support & SLA',           included: true },
    ],
  },
];

export default function PricingPage() {
  return (
    <div className="zu-section">
      <div className="zu-container">
        <div className="mx-auto mb-16 max-w-2xl text-center">
          <Badge variant="secondary" className="mb-4 rounded-full px-4 py-1">Pricing</Badge>
          <h1 className="font-display text-4xl font-bold tracking-tight sm:text-5xl">
            Simple, transparent{' '}
            <span className="zu-gradient-text">pricing</span>
          </h1>
          <p className="mt-4 text-lg text-muted-foreground">
            Start free and scale as you grow. Zu Platform grows with your organisation.
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-3 items-start">
          {PLANS.map((plan) => (
            <div
              key={plan.name}
              className={cn(
                'rounded-2xl border bg-card p-8 flex flex-col',
                plan.highlighted
                  ? 'border-zu-500 shadow-zu-xl ring-2 ring-zu-500/20'
                  : 'shadow-zu-sm'
              )}
            >
              {plan.highlighted && (
                <div className="mb-4 -mt-4 -mx-8 rounded-t-2xl zu-gradient-bg py-2 text-center text-xs font-bold text-white uppercase tracking-widest">
                  Most Popular
                </div>
              )}

              <div className="mb-6">
                <div className="flex items-center justify-between mb-2">
                  <h2 className="font-display text-2xl font-bold">{plan.name}</h2>
                  {plan.badge && (
                    <span className={cn('rounded-full px-3 py-1 text-xs font-medium', plan.badgeClass)}>
                      {plan.badge}
                    </span>
                  )}
                </div>
                <div className="mt-4 flex items-baseline gap-2">
                  <span className="font-display text-4xl font-extrabold">{plan.price}</span>
                  {plan.period && (
                    <span className="text-sm text-muted-foreground">{plan.period}</span>
                  )}
                </div>
                <p className="mt-3 text-sm text-muted-foreground">{plan.description}</p>
              </div>

              <Button
                size="lg"
                variant={plan.ctaVariant}
                asChild
                className={cn(
                  'w-full mb-8',
                  plan.highlighted && 'zu-gradient-bg text-white hover:opacity-90'
                )}
              >
                <Link href={plan.ctaHref}>
                  {plan.cta === 'Notify Me' && <Bell size={16} className="mr-2" />}
                  {plan.cta === 'Start Free' && <Zap size={16} className="mr-2" />}
                  {plan.cta}
                </Link>
              </Button>

              <ul className="space-y-3 flex-1">
                {plan.features.map((feature) => (
                  <li key={feature.label} className="flex items-start gap-3 text-sm">
                    {feature.included ? (
                      <Check size={16} className="mt-0.5 shrink-0 text-emerald-500" />
                    ) : (
                      <X size={16} className="mt-0.5 shrink-0 text-muted-foreground/40" />
                    )}
                    <span className={feature.included ? '' : 'text-muted-foreground/60'}>
                      {feature.label}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <p className="mt-12 text-center text-sm text-muted-foreground">
          Need a custom plan?{' '}
          <Link href="/contact" className="font-medium text-foreground underline underline-offset-4">
            Talk to our team
          </Link>{' '}
          about Enterprise and white-label options.
        </p>
      </div>
    </div>
  );
}
