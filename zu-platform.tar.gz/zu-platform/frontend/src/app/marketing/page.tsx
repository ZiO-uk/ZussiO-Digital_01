import { HeroSection } from '@/components/marketing/hero-section';
import { AppsSection } from '@/components/marketing/apps-section';
import { FeaturesSection } from '@/components/marketing/features-section';
import { TestimonialsSection } from '@/components/marketing/testimonials-section';
import { CtaSection } from '@/components/marketing/cta-section';

export default function HomePage() {
  return (
    <>
      <HeroSection />
      <AppsSection />
      <FeaturesSection />
      <TestimonialsSection />
      <CtaSection />
    </>
  );
}
