import { Metadata } from 'next';
import { Mail, MapPin, Phone } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export const metadata: Metadata = { title: 'Contact Us' };

export default function ContactPage() {
  return (
    <div className="zu-section">
      <div className="zu-container">
        <div className="mx-auto mb-12 max-w-2xl text-center">
          <Badge variant="secondary" className="mb-4 rounded-full px-4 py-1">Contact</Badge>
          <h1 className="font-display text-4xl font-bold tracking-tight sm:text-5xl">
            Let's talk
          </h1>
          <p className="mt-4 text-lg text-muted-foreground">
            Whether you're interested in the Gold plan, need a demo, or have a question,
            our team typically responds within one business day.
          </p>
        </div>

        <div className="mx-auto grid max-w-5xl gap-10 lg:grid-cols-5">
          {/* Contact info */}
          <aside className="lg:col-span-2 space-y-6">
            <div className="rounded-xl border bg-card p-6">
              <div className="space-y-5">
                <div className="flex items-start gap-3">
                  <Mail size={18} className="mt-0.5 text-zu-500 shrink-0" />
                  <div>
                    <p className="text-sm font-medium">Email</p>
                    <a href="mailto:hello@zuplatform.com" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                      hello@zuplatform.com
                    </a>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <MapPin size={18} className="mt-0.5 text-zu-500 shrink-0" />
                  <div>
                    <p className="text-sm font-medium">Location</p>
                    <p className="text-sm text-muted-foreground">Sheffield, England, UK</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Phone size={18} className="mt-0.5 text-zu-500 shrink-0" />
                  <div>
                    <p className="text-sm font-medium">Support hours</p>
                    <p className="text-sm text-muted-foreground">Mon–Fri, 9am–5pm GMT</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="rounded-xl border bg-card p-6">
              <h3 className="font-semibold mb-2">Sales enquiries</h3>
              <p className="text-sm text-muted-foreground mb-3">
                Interested in the Gold plan or a custom Enterprise arrangement?
                Select "Sales" in the form and we'll connect you with the right person.
              </p>
              <div className="text-sm font-medium text-zu-600 dark:text-zu-400">
                sales@zuplatform.com
              </div>
            </div>
          </aside>

          {/* Form */}
          <div className="lg:col-span-3">
            <form className="rounded-2xl border bg-card p-8 space-y-5">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="first_name">First name</Label>
                  <Input id="first_name" placeholder="Jane" required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="last_name">Last name</Label>
                  <Input id="last_name" placeholder="Smith" required />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Work email</Label>
                <Input id="email" type="email" placeholder="jane@company.com" required />
              </div>

              <div className="space-y-2">
                <Label htmlFor="company">Company</Label>
                <Input id="company" placeholder="Acme Ltd" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="topic">What's this about?</Label>
                <Select>
                  <SelectTrigger id="topic">
                    <SelectValue placeholder="Select a topic" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sales">Sales – Gold / Enterprise plan</SelectItem>
                    <SelectItem value="demo">Request a demo</SelectItem>
                    <SelectItem value="support">Technical support</SelectItem>
                    <SelectItem value="billing">Billing question</SelectItem>
                    <SelectItem value="partnership">Partnership enquiry</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="message">Message</Label>
                <Textarea
                  id="message"
                  placeholder="Tell us a bit about what you need..."
                  rows={5}
                  required
                />
              </div>

              <Button
                type="submit"
                size="lg"
                className="w-full zu-gradient-bg text-white hover:opacity-90"
              >
                Send message
              </Button>

              <p className="text-center text-xs text-muted-foreground">
                By submitting this form you agree to our{' '}
                <a href="/privacy" className="underline underline-offset-4">Privacy Policy</a>.
              </p>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
