import type { Metadata, Viewport } from 'next';
import { Inter } from 'next/font/google';
import { ClerkProvider } from '@clerk/nextjs';
import { ThemeProvider } from '@/components/layout/theme-provider';
import { Toaster } from '@/components/ui/sonner';
import './globals.css';

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
});

export const metadata: Metadata = {
  title: {
    default: 'Zu Platform – One Platform. Multiple Business Solutions.',
    template: '%s | Zu Platform',
  },
  description:
    'Zu Platform is an enterprise-grade modular business operating system. Manage compliance, send group eCards, handle documents and e-signatures – all under one roof.',
  keywords: ['SaaS', 'business platform', 'ISMS', 'compliance', 'documents', 'e-signature'],
  authors: [{ name: 'Zu Platform' }],
  openGraph: {
    type: 'website',
    locale: 'en_GB',
    url: 'https://zuplatform.com',
    siteName: 'Zu Platform',
    title: 'Zu Platform – One Platform. Multiple Business Solutions.',
    description: 'Enterprise-grade modular SaaS ecosystem for modern businesses.',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Zu Platform',
    description: 'Enterprise-grade modular SaaS ecosystem for modern businesses.',
  },
  robots: {
    index: true,
    follow: true,
  },
};

export const viewport: Viewport = {
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#6366f1' },
    { media: '(prefers-color-scheme: dark)',  color: '#4f46e5' },
  ],
  width: 'device-width',
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <ClerkProvider>
      <html lang="en-GB" suppressHydrationWarning>
        <body className={`${inter.variable} font-sans min-h-screen`}>
          <ThemeProvider
            attribute="class"
            defaultTheme="system"
            enableSystem
            disableTransitionOnChange
          >
            {children}
            <Toaster position="bottom-right" richColors />
          </ThemeProvider>
        </body>
      </html>
    </ClerkProvider>
  );
}
