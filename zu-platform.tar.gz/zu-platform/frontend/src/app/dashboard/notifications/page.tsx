import { Metadata } from 'next';
import { Bell, Check, Shield, FileText, CreditCard, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

export const metadata: Metadata = { title: 'Notifications' };

const NOTIFICATIONS = [
  {
    id: '1',
    type: 'action_required',
    app: 'zudoc',
    icon: FileText,
    iconBg: 'bg-emerald-100 text-emerald-600',
    title: 'Signature request awaiting your response',
    message: 'Mark Jones has requested your signature on "NDA – Thornton Consulting".',
    time: '5 minutes ago',
    read: false,
    actionLabel: 'View request',
    actionUrl: '/apps/zudoc',
  },
  {
    id: '2',
    type: 'warning',
    app: 'isms',
    icon: Shield,
    iconBg: 'bg-amber-100 text-amber-600',
    title: 'Control review overdue',
    message: 'Access Control (A.9.1) was due for review on 15 Jun 2024. Please review and update.',
    time: '2 hours ago',
    read: false,
    actionLabel: 'Open control',
    actionUrl: '/apps/isms',
  },
  {
    id: '3',
    type: 'info',
    app: 'zucards',
    icon: CreditCard,
    iconBg: 'bg-accent-100 text-accent-600',
    title: 'Card delivered to recipient',
    message: 'Your birthday card for "Sarah Mitchell" was delivered successfully.',
    time: '1 day ago',
    read: true,
    actionLabel: null,
    actionUrl: null,
  },
  {
    id: '4',
    type: 'success',
    app: null,
    icon: Info,
    iconBg: 'bg-zu-100 text-zu-600',
    title: 'Welcome to Zu Platform',
    message: 'Your account is set up and ready. Start with ZuCards or ZuDoc — both are free.',
    time: '3 days ago',
    read: true,
    actionLabel: 'Explore apps',
    actionUrl: '/dashboard/apps',
  },
];

export default function NotificationsPage() {
  const unreadCount = NOTIFICATIONS.filter((n) => !n.read).length;

  return (
    <div className="max-w-3xl space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold flex items-center gap-2">
            Notifications
            {unreadCount > 0 && (
              <Badge className="rounded-full bg-zu-500 text-white border-0 text-xs">
                {unreadCount} new
              </Badge>
            )}
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            Platform alerts, action items, and updates.
          </p>
        </div>
        <Button variant="ghost" size="sm">
          <Check size={15} className="mr-1.5" />
          Mark all read
        </Button>
      </div>

      <div className="rounded-xl border bg-card divide-y">
        {NOTIFICATIONS.map((n) => {
          const Icon = n.icon;
          return (
            <div
              key={n.id}
              className={cn(
                'flex items-start gap-4 p-5 transition-colors',
                !n.read && 'bg-zu-50/50 dark:bg-zu-950/20',
              )}
            >
              <div className={cn('mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full', n.iconBg)}>
                <Icon size={17} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-2">
                  <p className={cn('text-sm leading-tight', !n.read && 'font-semibold')}>
                    {n.title}
                  </p>
                  {!n.read && (
                    <div className="mt-1 h-2 w-2 shrink-0 rounded-full bg-zu-500" />
                  )}
                </div>
                <p className="mt-1 text-sm text-muted-foreground leading-relaxed">
                  {n.message}
                </p>
                <div className="mt-2 flex items-center gap-3">
                  <span className="text-xs text-muted-foreground">{n.time}</span>
                  {n.actionLabel && (
                    <a
                      href={n.actionUrl ?? '#'}
                      className="text-xs font-medium text-zu-600 dark:text-zu-400 hover:underline"
                    >
                      {n.actionLabel} →
                    </a>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {NOTIFICATIONS.length === 0 && (
        <div className="rounded-xl border bg-card p-12 text-center">
          <Bell size={32} className="mx-auto mb-3 text-muted-foreground/40" />
          <p className="font-medium">All caught up</p>
          <p className="text-sm text-muted-foreground mt-1">
            No notifications right now. We'll let you know when something needs your attention.
          </p>
        </div>
      )}
    </div>
  );
}
