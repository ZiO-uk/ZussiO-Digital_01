import { Metadata } from 'next';
import { CreditCard, Download, ArrowUpRight, Package } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import Link from 'next/link';

export const metadata: Metadata = { title: 'Billing' };

// In production these would come from API calls
const MOCK_SUBSCRIPTION = {
  plan: 'Free',
  status: 'Active',
  renewsAt: null,
  apps: ['ZuCards', 'ZuDoc'],
};

const MOCK_INVOICES = [
  { number: 'INV-2024-0003', date: '1 Jun 2024', amount: '£0.00', status: 'Paid' },
  { number: 'INV-2024-0002', date: '1 May 2024', amount: '£0.00', status: 'Paid' },
  { number: 'INV-2024-0001', date: '1 Apr 2024', amount: '£0.00', status: 'Paid' },
];

const USAGE = [
  { label: 'Users',          used: 4,   limit: 10,    unit: 'users' },
  { label: 'Storage',        used: 1.2, limit: 5,     unit: 'GB' },
  { label: 'Documents',      used: 23,  limit: null,  unit: 'docs' },
  { label: 'e-Signatures',   used: 2,   limit: 5,     unit: '/ month' },
];

export default function BillingPage() {
  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h1 className="font-display text-2xl font-bold">Billing & Subscription</h1>
        <p className="text-muted-foreground text-sm mt-1">
          Manage your plan, usage, and invoices.
        </p>
      </div>

      {/* Current plan */}
      <div className="rounded-xl border bg-card p-6">
        <div className="flex items-start justify-between mb-4">
          <div>
            <div className="flex items-center gap-2">
              <Package size={18} className="text-zu-500" />
              <h2 className="font-semibold">Current Plan</h2>
            </div>
          </div>
          <Badge className="bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400 border-0">
            {MOCK_SUBSCRIPTION.status}
          </Badge>
        </div>

        <div className="flex items-baseline gap-2 mb-2">
          <span className="font-display text-4xl font-extrabold">
            {MOCK_SUBSCRIPTION.plan}
          </span>
          <span className="text-muted-foreground">plan</span>
        </div>

        <p className="text-sm text-muted-foreground mb-4">
          Included applications:{' '}
          <span className="font-medium text-foreground">
            {MOCK_SUBSCRIPTION.apps.join(', ')}
          </span>
        </p>

        <div className="flex flex-wrap gap-3">
          <Button asChild className="zu-gradient-bg text-white hover:opacity-90">
            <Link href="/contact?plan=gold">
              <ArrowUpRight size={15} className="mr-1.5" />
              Upgrade to Gold
            </Link>
          </Button>
          <Button variant="outline" asChild>
            <Link href="/pricing">View all plans</Link>
          </Button>
        </div>
      </div>

      {/* Usage */}
      <div className="rounded-xl border bg-card p-6">
        <h2 className="font-semibold mb-5">Usage this period</h2>
        <div className="grid gap-5 sm:grid-cols-2">
          {USAGE.map((u) => {
            const pct = u.limit ? Math.min(Math.round((u.used / u.limit) * 100), 100) : null;
            return (
              <div key={u.label}>
                <div className="flex items-center justify-between text-sm mb-1.5">
                  <span className="font-medium">{u.label}</span>
                  <span className="text-muted-foreground">
                    {u.used} {u.unit}
                    {u.limit && ` / ${u.limit} ${u.unit}`}
                    {!u.limit && ' (unlimited)'}
                  </span>
                </div>
                {pct !== null && (
                  <div className="h-2 rounded-full bg-muted overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${
                        pct > 80 ? 'bg-amber-500' : 'bg-zu-500'
                      }`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Payment method placeholder */}
      <div className="rounded-xl border bg-card p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <CreditCard size={18} className="text-zu-500" />
            <h2 className="font-semibold">Payment Method</h2>
          </div>
        </div>
        <p className="text-sm text-muted-foreground">
          No payment method on file. A card is required when upgrading to a paid plan.
        </p>
        <Button variant="outline" size="sm" className="mt-4">
          Add payment method
        </Button>
      </div>

      {/* Invoices */}
      <div className="rounded-xl border bg-card p-6">
        <h2 className="font-semibold mb-5">Invoice history</h2>
        {MOCK_INVOICES.length === 0 ? (
          <p className="text-sm text-muted-foreground">No invoices yet.</p>
        ) : (
          <div className="space-y-0">
            {MOCK_INVOICES.map((inv, i) => (
              <div key={inv.number}>
                <div className="flex items-center justify-between py-3">
                  <div>
                    <p className="text-sm font-medium">{inv.number}</p>
                    <p className="text-xs text-muted-foreground">{inv.date}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-medium">{inv.amount}</span>
                    <Badge variant="secondary" className="text-xs">
                      {inv.status}
                    </Badge>
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <Download size={14} />
                    </Button>
                  </div>
                </div>
                {i < MOCK_INVOICES.length - 1 && <Separator />}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
