'use client';

import { usePathname } from 'next/navigation';
import Link from 'next/link';
import { UserButton } from '@clerk/nextjs';
import {
  LayoutDashboard, AppWindow, Bell, Settings, CreditCard,
  Shield, FileText, Zap, ChevronDown, Menu, X
} from 'lucide-react';
import { useState } from 'react';
import { cn } from '@/lib/utils';
import { ModeToggle } from '@/components/layout/mode-toggle';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

const NAV_ITEMS = [
  { href: '/dashboard',              icon: LayoutDashboard, label: 'Dashboard' },
  { href: '/dashboard/apps',         icon: AppWindow,       label: 'Applications' },
  { href: '/dashboard/notifications',icon: Bell,            label: 'Notifications', badge: 3 },
  { href: '/dashboard/billing',      icon: CreditCard,      label: 'Billing' },
  { href: '/dashboard/settings',     icon: Settings,        label: 'Settings' },
];

const APP_NAV_ITEMS = [
  { href: '/apps/isms',    icon: Shield,   label: 'ISMS Trustee', colour: 'text-zu-500' },
  { href: '/apps/zucards', icon: Zap,      label: 'ZuCards',      colour: 'text-accent-500' },
  { href: '/apps/zudoc',   icon: FileText, label: 'ZuDoc',        colour: 'text-emerald-500' },
];

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="flex min-h-screen bg-muted/20">
      {/* Sidebar – desktop */}
      <aside className="hidden w-60 shrink-0 flex-col border-r bg-card lg:flex">
        <SidebarContent pathname={pathname} />
      </aside>

      {/* Sidebar – mobile overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setSidebarOpen(false)} />
          <aside className="absolute left-0 top-0 bottom-0 w-60 bg-card border-r flex flex-col">
            <SidebarContent pathname={pathname} onClose={() => setSidebarOpen(false)} />
          </aside>
        </div>
      )}

      {/* Main content area */}
      <div className="flex flex-1 flex-col">
        {/* Top bar */}
        <header className="sticky top-0 z-40 flex h-14 items-center gap-4 border-b bg-card/80 backdrop-blur px-4 lg:px-6">
          <button
            className="lg:hidden"
            onClick={() => setSidebarOpen(true)}
            aria-label="Open sidebar"
          >
            <Menu size={20} />
          </button>

          <div className="flex flex-1 items-center justify-between">
            <div /> {/* spacer */}
            <div className="flex items-center gap-3">
              <ModeToggle />
              <Button variant="ghost" size="icon" asChild className="relative">
                <Link href="/dashboard/notifications">
                  <Bell size={18} />
                  <span className="absolute top-1 right-1 h-2 w-2 rounded-full bg-zu-500" />
                </Link>
              </Button>
              <UserButton afterSignOutUrl="/" />
            </div>
          </div>
        </header>

        <main className="flex-1 p-4 lg:p-6">
          {children}
        </main>
      </div>
    </div>
  );
}

function SidebarContent({ pathname, onClose }: { pathname: string; onClose?: () => void }) {
  return (
    <>
      {/* Logo */}
      <div className="flex h-14 items-center border-b px-4">
        <Link href="/dashboard" className="flex items-center gap-2 font-display font-bold text-lg" onClick={onClose}>
          <div className="flex h-7 w-7 items-center justify-center rounded-lg zu-gradient-bg text-white">
            <Zap size={14} />
          </div>
          <span className="zu-gradient-text">Zu Platform</span>
        </Link>
        {onClose && (
          <button className="ml-auto" onClick={onClose}><X size={18} /></button>
        )}
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto p-3 space-y-0.5">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const active = pathname === item.href;
          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={onClose}
              className={cn('nav-item', active && 'nav-item-active')}
            >
              <Icon size={17} />
              <span className="flex-1">{item.label}</span>
              {item.badge && (
                <Badge className="h-5 w-5 justify-center p-0 text-xs rounded-full bg-zu-500">
                  {item.badge}
                </Badge>
              )}
            </Link>
          );
        })}

        {/* Apps group */}
        <div className="pt-4">
          <p className="mb-1 px-3 text-xs font-semibold text-muted-foreground uppercase tracking-widest">
            Applications
          </p>
          {APP_NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = pathname.startsWith(item.href);
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={onClose}
                className={cn('nav-item', active && 'nav-item-active')}
              >
                <Icon size={17} className={item.colour} />
                <span>{item.label}</span>
              </Link>
            );
          })}
        </div>
      </nav>

      {/* Footer */}
      <div className="border-t p-3">
        <div className="rounded-lg bg-zu-50 dark:bg-zu-950/30 p-3">
          <p className="text-xs font-medium text-zu-700 dark:text-zu-300">Free Plan</p>
          <p className="text-xs text-muted-foreground mt-0.5">Upgrade for ISMS Trustee</p>
          <Link
            href="/dashboard/billing"
            className="mt-2 block text-xs font-semibold text-zu-600 dark:text-zu-400 hover:underline"
          >
            Upgrade plan →
          </Link>
        </div>
      </div>
    </>
  );
}
