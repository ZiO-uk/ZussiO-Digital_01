import { Metadata } from 'next';
import { Activity, Users, DollarSign, TrendingUp, Shield, FileText, Zap, CheckCircle, AlertTriangle, XCircle } from 'lucide-react';

export const metadata: Metadata = { title: 'Dashboard' };

export default function DashboardPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold">Dashboard</h1>
        <p className="text-muted-foreground text-sm mt-1">
          Welcome back. Here's what's happening across your platform.
        </p>
      </div>

      {/* System Health */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <MetricCard
          title="System Status"
          value="Operational"
          icon={Activity}
          trend="+99.9% uptime"
          trendPositive
          iconBg="bg-emerald-50 dark:bg-emerald-950/30"
          iconColour="text-emerald-500"
        />
        <MetricCard
          title="Active Users"
          value="1,284"
          icon={Users}
          trend="+12% this month"
          trendPositive
          iconBg="bg-zu-50 dark:bg-zu-950/30"
          iconColour="text-zu-500"
        />
        <MetricCard
          title="Monthly Revenue"
          value="£8,420"
          icon={DollarSign}
          trend="+8.2% vs last month"
          trendPositive
          iconBg="bg-amber-50 dark:bg-amber-950/30"
          iconColour="text-amber-500"
        />
        <MetricCard
          title="Active Subscriptions"
          value="94"
          icon={TrendingUp}
          trend="+5 this week"
          trendPositive
          iconBg="bg-violet-50 dark:bg-violet-950/30"
          iconColour="text-violet-500"
        />
      </div>

      {/* Service Health Grid */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <div className="rounded-xl border bg-card p-5">
          <h3 className="font-semibold text-sm mb-4">Service Health</h3>
          <div className="space-y-3">
            {[
              { name: 'API Gateway',   status: 'online' },
              { name: 'Database',      status: 'online' },
              { name: 'File Storage',  status: 'online' },
              { name: 'Email Service', status: 'online' },
              { name: 'Auth (Clerk)',  status: 'online' },
              { name: 'Payments',      status: 'warning' },
            ].map((s) => (
              <div key={s.name} className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">{s.name}</span>
                <span className={`flex items-center gap-1.5 font-medium ${
                  s.status === 'online'  ? 'text-emerald-600' :
                  s.status === 'warning' ? 'text-amber-600'   : 'text-red-600'
                }`}>
                  {s.status === 'online'  && <CheckCircle size={13} />}
                  {s.status === 'warning' && <AlertTriangle size={13} />}
                  {s.status === 'offline' && <XCircle size={13} />}
                  {s.status === 'online' ? 'Online' : s.status === 'warning' ? 'Degraded' : 'Offline'}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* App Usage */}
        <div className="rounded-xl border bg-card p-5">
          <h3 className="font-semibold text-sm mb-4">Application Usage</h3>
          <div className="space-y-4">
            {[
              { name: 'ZuDoc',        pct: 72, colour: 'bg-emerald-500', icon: FileText },
              { name: 'ZuCards',      pct: 58, colour: 'bg-accent-500',  icon: Zap },
              { name: 'ISMS Trustee', pct: 34, colour: 'bg-zu-500',      icon: Shield },
            ].map((app) => {
              const Icon = app.icon;
              return (
                <div key={app.name}>
                  <div className="flex items-center justify-between text-sm mb-1.5">
                    <span className="flex items-center gap-2">
                      <Icon size={14} className="text-muted-foreground" />
                      {app.name}
                    </span>
                    <span className="text-muted-foreground">{app.pct}%</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                    <div
                      className={`h-full rounded-full ${app.colour}`}
                      style={{ width: `${app.pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Recent Activity */}
        <div className="rounded-xl border bg-card p-5">
          <h3 className="font-semibold text-sm mb-4">Recent Activity</h3>
          <div className="space-y-3">
            {[
              { msg: 'New tenant: Acme Ltd',         time: '2m ago',   colour: 'bg-zu-500' },
              { msg: 'Invoice #0094 paid',            time: '14m ago',  colour: 'bg-emerald-500' },
              { msg: 'Policy approved: Data Sec.',    time: '1h ago',   colour: 'bg-violet-500' },
              { msg: 'Card delivered to J. Smith',    time: '2h ago',   colour: 'bg-accent-500' },
              { msg: 'Doc signed: NDA – Thornton',    time: '3h ago',   colour: 'bg-emerald-500' },
            ].map((item, i) => (
              <div key={i} className="flex items-start gap-3 text-sm">
                <div className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${item.colour}`} />
                <div>
                  <p className="leading-tight">{item.msg}</p>
                  <p className="text-xs text-muted-foreground">{item.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Revenue metrics */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[
          { label: 'MRR',              value: '£8,420',  sub: 'Monthly Recurring Revenue' },
          { label: 'ARR',              value: '£101k',   sub: 'Annual Recurring Revenue' },
          { label: 'Churn Rate',       value: '1.2%',    sub: 'Last 30 days' },
          { label: 'Trial Conversion', value: '34.8%',   sub: 'Trials → Paid' },
        ].map((m) => (
          <div key={m.label} className="rounded-xl border bg-card p-5">
            <p className="text-xs text-muted-foreground uppercase tracking-widest">{m.label}</p>
            <p className="font-display text-3xl font-extrabold mt-1">{m.value}</p>
            <p className="text-xs text-muted-foreground mt-1">{m.sub}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function MetricCard({
  title, value, icon: Icon, trend, trendPositive, iconBg, iconColour
}: {
  title: string; value: string; icon: React.ElementType;
  trend: string; trendPositive: boolean;
  iconBg: string; iconColour: string;
}) {
  return (
    <div className="rounded-xl border bg-card p-5">
      <div className="flex items-center justify-between mb-3">
        <p className="text-sm font-medium text-muted-foreground">{title}</p>
        <div className={`rounded-lg p-2 ${iconBg}`}>
          <Icon size={16} className={iconColour} />
        </div>
      </div>
      <p className="font-display text-2xl font-bold">{value}</p>
      <p className={`text-xs mt-1 ${trendPositive ? 'text-emerald-600' : 'text-red-600'}`}>
        {trend}
      </p>
    </div>
  );
}
