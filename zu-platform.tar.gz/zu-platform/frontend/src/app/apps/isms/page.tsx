import { Metadata } from 'next';
import { Shield, AlertTriangle, CheckCircle, FileText, ClipboardList, Lock } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import Link from 'next/link';

export const metadata: Metadata = { title: 'ISMS Trustee' };

const FEATURES = [
  {
    icon: AlertTriangle,
    title: 'Risk Register',
    desc: 'Create and manage information security risks with automatic scoring, treatment plans, and owner assignments. Visual 5×5 risk matrix included.',
    colour: 'bg-zu-50 text-zu-600 dark:bg-zu-950/30',
  },
  {
    icon: Shield,
    title: 'Framework Management',
    desc: 'Structured control libraries for ISO 27001, Cyber Essentials, and GDPR. Track status, assign owners, and link evidence to every control.',
    colour: 'bg-violet-50 text-violet-600 dark:bg-violet-950/30',
  },
  {
    icon: FileText,
    title: 'Policy Management',
    desc: 'Draft, version, approve, and distribute security policies. Track employee acknowledgements with a full audit trail.',
    colour: 'bg-emerald-50 text-emerald-600 dark:bg-emerald-950/30',
  },
  {
    icon: ClipboardList,
    title: 'Audit Management',
    desc: 'Plan internal audits, record findings, raise corrective actions, and track resolution through to closure.',
    colour: 'bg-amber-50 text-amber-600 dark:bg-amber-950/30',
  },
  {
    icon: Lock,
    title: 'Evidence Management',
    desc: 'Attach evidence files to controls, set expiry reminders, and always know what's current versus expired.',
    colour: 'bg-rose-50 text-rose-600 dark:bg-rose-950/30',
  },
  {
    icon: CheckCircle,
    title: 'Compliance Reporting',
    desc: 'Generate executive dashboards, compliance summaries, and audit-ready reports with a single click.',
    colour: 'bg-sky-50 text-sky-600 dark:bg-sky-950/30',
  },
];

const FRAMEWORKS = [
  { name: 'ISO 27001:2022', desc: '93 controls mapped and ready to populate', status: 'Available' },
  { name: 'Cyber Essentials', desc: 'NCSC framework with structured evidence requirements', status: 'Available' },
  { name: 'GDPR', desc: 'Article-by-article compliance tracking', status: 'Available' },
  { name: 'ISO 27002', desc: 'Extended control guidance', status: 'Coming Soon' },
  { name: 'NIST CSF', desc: 'US cybersecurity framework', status: 'Coming Soon' },
  { name: 'SOC 2', desc: 'Trust service criteria', status: 'Coming Soon' },
];

export default function IsmsPage() {
  return (
    <div>
      {/* Hero */}
      <section className="zu-hero-section border-b">
        <div className="zu-container">
          <div className="mx-auto max-w-3xl text-center">
            <div className="mb-6 inline-flex h-16 w-16 items-center justify-center rounded-2xl bg-zu-500 text-white shadow-zu-lg">
              <Shield size={30} />
            </div>
            <Badge className="mb-4 rounded-full px-4 py-1 bg-zu-100 text-zu-700 dark:bg-zu-950 dark:text-zu-300 border-0">
              Gold Plan
            </Badge>
            <h1 className="font-display text-5xl font-extrabold tracking-tight sm:text-6xl">
              ISMS Trustee
            </h1>
            <p className="mt-4 text-xl font-medium text-zu-600 dark:text-zu-400">
              Information Security Management, simplified.
            </p>
            <p className="mt-4 text-lg text-muted-foreground leading-relaxed">
              Everything you need to achieve and maintain ISO 27001, Cyber Essentials,
              and GDPR compliance — without the spreadsheets, the consultants, or the chaos.
            </p>
            <div className="mt-8 flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
              <Button size="lg" asChild className="zu-gradient-bg text-white hover:opacity-90 px-8">
                <Link href="/contact?plan=gold">Contact Sales</Link>
              </Button>
              <Button size="lg" variant="outline" asChild className="px-8">
                <Link href="/pricing">View pricing</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="zu-section">
        <div className="zu-container">
          <h2 className="font-display text-3xl font-bold text-center mb-12">
            Everything in one place
          </h2>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {FEATURES.map((f) => {
              const Icon = f.icon;
              return (
                <div key={f.title} className="rounded-xl border bg-card p-6">
                  <div className={`mb-4 inline-flex h-10 w-10 items-center justify-center rounded-xl ${f.colour}`}>
                    <Icon size={18} />
                  </div>
                  <h3 className="font-display text-lg font-bold mb-2">{f.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Frameworks */}
      <section className="zu-section bg-muted/30">
        <div className="zu-container">
          <div className="mx-auto mb-10 max-w-2xl text-center">
            <h2 className="font-display text-3xl font-bold">Supported frameworks</h2>
            <p className="mt-3 text-muted-foreground">
              Start with what you need now. More frameworks are added continuously.
            </p>
          </div>
          <div className="mx-auto max-w-3xl grid gap-4 sm:grid-cols-2">
            {FRAMEWORKS.map((f) => (
              <div key={f.name} className="flex items-start gap-4 rounded-xl border bg-card p-5">
                <div className={`mt-0.5 h-2 w-2 shrink-0 rounded-full ${
                  f.status === 'Available' ? 'bg-emerald-500' : 'bg-muted-foreground/40'
                }`} />
                <div>
                  <div className="flex items-center gap-2">
                    <p className="font-medium text-sm">{f.name}</p>
                    <Badge variant={f.status === 'Available' ? 'secondary' : 'outline'} className="text-xs px-2 py-0">
                      {f.status}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mt-0.5">{f.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
