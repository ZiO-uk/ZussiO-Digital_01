import { Metadata } from 'next';
import { CreditCard, Users, Send, Palette, Calendar, Gift } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import Link from 'next/link';

export const metadata: Metadata = { title: 'ZuCards' };

const CATEGORIES = [
  { emoji: '🎂', label: 'Birthdays' },
  { emoji: '🏆', label: 'Work Anniversaries' },
  { emoji: '👋', label: 'Farewells' },
  { emoji: '🎉', label: 'Congratulations' },
  { emoji: '🎄', label: 'Holidays' },
  { emoji: '✨', label: 'Custom' },
];

const HOW_IT_WORKS = [
  { step: '01', title: 'Choose a template', desc: 'Pick from dozens of beautiful card templates across every category, or start from scratch.' },
  { step: '02', title: 'Share the link',    desc: 'Send a contribution link to your team by email or Slack. Anyone can add a message — no account needed.' },
  { step: '03', title: 'Deliver with joy',  desc: 'Schedule delivery or send immediately. The recipient gets a beautifully laid-out card with every message.' },
];

export default function ZuCardsPage() {
  return (
    <div>
      {/* Hero */}
      <section className="zu-hero-section border-b">
        <div className="zu-container">
          <div className="mx-auto max-w-3xl text-center">
            <div className="mb-6 inline-flex h-16 w-16 items-center justify-center rounded-2xl bg-accent-500 text-white shadow-zu-lg">
              <CreditCard size={30} />
            </div>
            <Badge className="mb-4 rounded-full px-4 py-1 bg-accent-100 text-accent-700 dark:bg-accent-950 dark:text-accent-300 border-0">
              Free Plan
            </Badge>
            <h1 className="font-display text-5xl font-extrabold tracking-tight sm:text-6xl">
              ZuCards
            </h1>
            <p className="mt-4 text-xl font-medium text-accent-600 dark:text-accent-400">
              Group cards your whole team actually wants to sign.
            </p>
            <p className="mt-4 text-lg text-muted-foreground leading-relaxed max-w-xl mx-auto">
              Create beautiful eCards, collect messages from everyone in your team,
              and deliver something that genuinely moves people — all in minutes.
            </p>
            <div className="mt-8 flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
              <Button size="lg" asChild className="bg-accent-500 hover:bg-accent-600 text-white px-8">
                <Link href="/sign-up">Create a card – Free</Link>
              </Button>
              <Button size="lg" variant="outline" asChild className="px-8">
                <Link href="/sign-in">Sign in</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="zu-section">
        <div className="zu-container">
          <h2 className="font-display text-3xl font-bold text-center mb-10">
            A card for every occasion
          </h2>
          <div className="flex flex-wrap justify-center gap-4">
            {CATEGORIES.map((c) => (
              <div key={c.label} className="flex items-center gap-3 rounded-full border bg-card px-5 py-2.5 shadow-zu-sm">
                <span className="text-2xl">{c.emoji}</span>
                <span className="font-medium text-sm">{c.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="zu-section bg-muted/30">
        <div className="zu-container">
          <h2 className="font-display text-3xl font-bold text-center mb-12">
            Three steps to a perfect card
          </h2>
          <div className="grid gap-8 md:grid-cols-3">
            {HOW_IT_WORKS.map((step) => (
              <div key={step.step} className="text-center">
                <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-accent-500 text-white font-display font-bold text-lg">
                  {step.step}
                </div>
                <h3 className="font-display text-xl font-bold mb-2">{step.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features grid */}
      <section className="zu-section">
        <div className="zu-container">
          <h2 className="font-display text-3xl font-bold text-center mb-12">
            Everything you need
          </h2>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {[
              { icon: Palette, title: 'Drag-and-drop designer',  desc: 'Customise layouts, add images, GIFs, and stickers.' },
              { icon: Users,   title: 'Unlimited contributors',   desc: 'No cap on who can sign. No account required to contribute.' },
              { icon: Calendar,title: 'Scheduled delivery',       desc: 'Pick the perfect moment — a birthday morning, last day in the office.' },
              { icon: Send,    title: 'Email & link delivery',    desc: 'Deliver by email or shareable link. Works everywhere.' },
              { icon: Gift,    title: 'GIF & sticker support',    desc: 'Giphy integration lets contributors add movement to their messages.' },
              { icon: CreditCard, title: 'Card history',          desc: 'View all cards sent, contributions received, and delivery status.' },
            ].map((f) => {
              const Icon = f.icon;
              return (
                <div key={f.title} className="rounded-xl border bg-card p-5">
                  <Icon size={20} className="mb-3 text-accent-500" />
                  <h3 className="font-semibold mb-1.5">{f.title}</h3>
                  <p className="text-sm text-muted-foreground">{f.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
}
