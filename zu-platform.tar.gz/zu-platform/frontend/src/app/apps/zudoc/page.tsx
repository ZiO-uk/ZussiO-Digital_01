import { Metadata } from 'next';
import { FileText, FolderOpen, Share2, PenTool, History, Tag } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import Link from 'next/link';

export const metadata: Metadata = { title: 'ZuDoc' };

const USE_CASES = [
  'Tenancy agreements', 'NDAs', 'Employment contracts', 'Business agreements',
  'HR documents', 'Supplier contracts', 'Board resolutions', 'Service agreements',
];

export default function ZuDocPage() {
  return (
    <div>
      {/* Hero */}
      <section className="zu-hero-section border-b">
        <div className="zu-container">
          <div className="mx-auto max-w-3xl text-center">
            <div className="mb-6 inline-flex h-16 w-16 items-center justify-center rounded-2xl bg-emerald-500 text-white shadow-zu-lg">
              <FileText size={30} />
            </div>
            <Badge className="mb-4 rounded-full px-4 py-1 bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 border-0">
              Free Plan
            </Badge>
            <h1 className="font-display text-5xl font-extrabold tracking-tight sm:text-6xl">
              ZuDoc
            </h1>
            <p className="mt-4 text-xl font-medium text-emerald-600 dark:text-emerald-400">
              Write, store, share, and sign — all in one place.
            </p>
            <p className="mt-4 text-lg text-muted-foreground leading-relaxed max-w-xl mx-auto">
              A powerful document platform with a rich editor, unlimited storage, version
              history, secure sharing, and legally-compliant e-signatures built in from day one.
            </p>
            <div className="mt-8 flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
              <Button size="lg" asChild className="bg-emerald-600 hover:bg-emerald-700 text-white px-8">
                <Link href="/sign-up">Start for free</Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link href="/sign-in">Sign in</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="zu-section">
        <div className="zu-container">
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {[
              {
                icon: FileText,
                title: 'Rich document editor',
                desc: 'A full-featured editor with headings, tables, lists, images, and formatting tools. Start from a template or blank page.',
                colour: 'bg-emerald-50 text-emerald-600 dark:bg-emerald-950/30',
              },
              {
                icon: FolderOpen,
                title: 'Organised storage',
                desc: 'Unlimited folders, full-text search, tags, and version history. Find any document in seconds.',
                colour: 'bg-zu-50 text-zu-600 dark:bg-zu-950/30',
              },
              {
                icon: Share2,
                title: 'Secure sharing',
                desc: 'Share with view, comment, or edit permissions. Set link expiry dates to automatically revoke access.',
                colour: 'bg-sky-50 text-sky-600 dark:bg-sky-950/30',
              },
              {
                icon: PenTool,
                title: 'E-Signatures',
                desc: 'Request signatures from multiple parties in order. Draw, type, or upload a signature. Full audit trail included.',
                colour: 'bg-violet-50 text-violet-600 dark:bg-violet-950/30',
              },
              {
                icon: History,
                title: 'Version history',
                desc: 'Every change is saved. Restore any previous version at any time without losing current work.',
                colour: 'bg-amber-50 text-amber-600 dark:bg-amber-950/30',
              },
              {
                icon: Tag,
                title: 'Tags & search',
                desc: 'Tag documents by project, department, or type. Full-text search finds content anywhere in your library.',
                colour: 'bg-rose-50 text-rose-600 dark:bg-rose-950/30',
              },
            ].map((f) => {
              const Icon = f.icon;
              return (
                <div key={f.title} className="rounded-xl border bg-card p-6">
                  <div className={`mb-4 inline-flex h-10 w-10 items-center justify-center rounded-xl ${f.colour}`}>
                    <Icon size={18} />
                  </div>
                  <h3 className="font-display text-lg font-bold mb-2">{f.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Use cases */}
      <section className="zu-section bg-muted/30">
        <div className="zu-container">
          <div className="mx-auto max-w-2xl text-center mb-10">
            <h2 className="font-display text-3xl font-bold">What people sign with ZuDoc</h2>
          </div>
          <div className="flex flex-wrap justify-center gap-3">
            {USE_CASES.map((uc) => (
              <span key={uc} className="rounded-full border bg-card px-5 py-2 text-sm font-medium shadow-zu-sm">
                {uc}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* E-signature callout */}
      <section className="zu-section">
        <div className="zu-container">
          <div className="mx-auto max-w-4xl rounded-2xl border bg-card p-8 sm:p-12">
            <div className="grid gap-8 md:grid-cols-2 items-center">
              <div>
                <h2 className="font-display text-3xl font-bold mb-4">
                  Legally compliant e-signatures
                </h2>
                <p className="text-muted-foreground leading-relaxed">
                  Every signature request generates a tamper-evident audit trail capturing
                  IP addresses, timestamps, and identity verification steps. Admissible
                  evidence under UK eIDAS regulations.
                </p>
                <ul className="mt-4 space-y-2">
                  {['Sequential or parallel signing', 'Automatic reminders', 'Completion certificates', 'Permanent audit log'].map((item) => (
                    <li key={item} className="flex items-center gap-2 text-sm">
                      <div className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="rounded-xl border bg-muted/50 p-6 space-y-3">
                {[
                  { label: 'Document sent',       time: '09:14', status: 'done' },
                  { label: 'Jane Smith viewed',   time: '09:22', status: 'done' },
                  { label: 'Jane Smith signed',   time: '09:24', status: 'done' },
                  { label: 'Mark Jones notified', time: '09:24', status: 'done' },
                  { label: 'Mark Jones signing',  time: '',      status: 'pending' },
                ].map((entry, i) => (
                  <div key={i} className="flex items-center gap-3 text-xs">
                    <div className={`h-2 w-2 shrink-0 rounded-full ${
                      entry.status === 'done' ? 'bg-emerald-500' : 'bg-amber-400 animate-pulse'
                    }`} />
                    <span className="flex-1 font-medium">{entry.label}</span>
                    <span className="text-muted-foreground">{entry.time}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
