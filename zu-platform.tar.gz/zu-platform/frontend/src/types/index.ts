// ============================================================
// Zu Platform – Global TypeScript Types
// ============================================================

// ─── User & Auth ────────────────────────────────────────────
export type UserRole =
  | 'super_admin'
  | 'platform_manager'
  | 'tenant_admin'
  | 'standard_user'
  | 'read_only';

export interface User {
  id: string;
  clerkId: string;
  email: string;
  name: string;
  avatarUrl?: string;
  role: UserRole;
  tenantId: string;
  isActive: boolean;
  mfaEnabled: boolean;
  lastLoginAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}

// ─── Tenant ─────────────────────────────────────────────────
export type SubscriptionStatus =
  | 'trial'
  | 'active'
  | 'past_due'
  | 'suspended'
  | 'cancelled'
  | 'expired';

export type PlanSlug = 'free' | 'silver' | 'gold' | 'enterprise';

export interface Tenant {
  id: string;
  name: string;
  slug: string;
  logoUrl?: string;
  primaryColour?: string;
  plan: PlanSlug;
  subscriptionStatus: SubscriptionStatus;
  trialEndsAt?: Date;
  userCount: number;
  storageUsedBytes: number;
  storageLimitBytes: number;
  createdAt: Date;
  updatedAt: Date;
}

// ─── Billing ─────────────────────────────────────────────────
export interface SubscriptionPlan {
  id: string;
  slug: PlanSlug;
  name: string;
  description: string;
  priceMonthlyGbp: number | null;
  priceAnnualGbp: number | null;
  features: string[];
  limits: PlanLimits;
  isPublic: boolean;
  isActive: boolean;
}

export interface PlanLimits {
  maxUsers: number | null;       // null = unlimited
  maxStorageBytes: number | null;
  maxDocuments: number | null;
  maxCards: number | null;
  apiCallsPerDay: number | null;
  signatureRequestsPerMonth: number | null;
}

export interface ApplicationEntitlement {
  id: string;
  planSlug: PlanSlug;
  appSlug: AppSlug;
  enabled: boolean;
}

export interface FeatureFlag {
  id: string;
  key: string;
  appSlug: AppSlug;
  planSlug: PlanSlug;
  enabled: boolean;
  description: string;
}

export interface Invoice {
  id: string;
  tenantId: string;
  number: string;
  status: 'draft' | 'open' | 'paid' | 'void' | 'uncollectible';
  amountGbp: number;
  taxAmountGbp: number;
  totalGbp: number;
  billingPeriodStart: Date;
  billingPeriodEnd: Date;
  dueDate: Date;
  paidAt?: Date;
  pdfUrl?: string;
  createdAt: Date;
}

// ─── Applications ────────────────────────────────────────────
export type AppSlug = 'isms' | 'zucards' | 'zudoc';

export interface AppDefinition {
  slug: AppSlug;
  name: string;
  tagline: string;
  description: string;
  iconName: string;
  colour: string;
  requiredPlan: PlanSlug;
  path: string;
  isActive: boolean;
}

// ─── ISMS Trustee ────────────────────────────────────────────
export type RiskSeverity = 'low' | 'medium' | 'high' | 'critical';
export type RiskStatus = 'open' | 'in_treatment' | 'accepted' | 'closed';
export type ControlStatus = 'not_started' | 'in_progress' | 'implemented' | 'not_applicable';
export type ComplianceFramework = 'iso27001' | 'cyber_essentials' | 'gdpr';

export interface Risk {
  id: string;
  tenantId: string;
  title: string;
  description: string;
  likelihood: 1 | 2 | 3 | 4 | 5;
  impact: 1 | 2 | 3 | 4 | 5;
  riskScore: number;
  severity: RiskSeverity;
  status: RiskStatus;
  ownerId: string;
  owner?: User;
  treatmentPlan?: string;
  dueDate?: Date;
  tags: string[];
  createdAt: Date;
  updatedAt: Date;
}

export interface Control {
  id: string;
  tenantId: string;
  framework: ComplianceFramework;
  controlRef: string;
  title: string;
  description: string;
  status: ControlStatus;
  ownerId?: string;
  owner?: User;
  evidence: Evidence[];
  lastReviewedAt?: Date;
  nextReviewAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface Policy {
  id: string;
  tenantId: string;
  title: string;
  content: string;
  version: string;
  status: 'draft' | 'pending_approval' | 'approved' | 'archived';
  approvedById?: string;
  approvedAt?: Date;
  reviewDate?: Date;
  acknowledgements: PolicyAcknowledgement[];
  createdAt: Date;
  updatedAt: Date;
}

export interface PolicyAcknowledgement {
  id: string;
  policyId: string;
  userId: string;
  user?: User;
  acknowledgedAt: Date;
}

export interface Evidence {
  id: string;
  tenantId: string;
  title: string;
  description?: string;
  fileUrl: string;
  fileName: string;
  fileType: string;
  fileSizeBytes: number;
  expiresAt?: Date;
  uploadedById: string;
  createdAt: Date;
}

// ─── ZuCards ─────────────────────────────────────────────────
export type CardCategory =
  | 'birthday'
  | 'work_anniversary'
  | 'farewell'
  | 'congratulations'
  | 'holiday'
  | 'custom';

export interface CardTemplate {
  id: string;
  name: string;
  category: CardCategory;
  thumbnailUrl: string;
  designData: Record<string, unknown>;
  isPremium: boolean;
  isActive: boolean;
}

export interface GroupCard {
  id: string;
  tenantId: string;
  title: string;
  recipientName: string;
  recipientEmail: string;
  templateId: string;
  template?: CardTemplate;
  category: CardCategory;
  designData: Record<string, unknown>;
  scheduledDeliveryAt?: Date;
  deliveredAt?: Date;
  shareableLink: string;
  contributions: CardContribution[];
  status: 'draft' | 'collecting' | 'scheduled' | 'delivered';
  createdById: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface CardContribution {
  id: string;
  cardId: string;
  contributorName: string;
  contributorEmail?: string;
  message: string;
  gifUrl?: string;
  stickerUrl?: string;
  position: { x: number; y: number };
  createdAt: Date;
}

// ─── ZuDoc ────────────────────────────────────────────────────
export type DocumentStatus = 'draft' | 'active' | 'archived';

export interface Document {
  id: string;
  tenantId: string;
  title: string;
  content: string;
  folderId?: string;
  status: DocumentStatus;
  tags: string[];
  version: number;
  versions: DocumentVersion[];
  sharedLinks: SharedLink[];
  signatureRequests: SignatureRequest[];
  createdById: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface DocumentVersion {
  id: string;
  documentId: string;
  version: number;
  content: string;
  changedById: string;
  changeSummary?: string;
  createdAt: Date;
}

export interface SharedLink {
  id: string;
  documentId: string;
  token: string;
  permissions: 'view' | 'comment' | 'edit';
  expiresAt?: Date;
  isActive: boolean;
  createdAt: Date;
}

export interface SignatureRequest {
  id: string;
  documentId: string;
  document?: Document;
  title: string;
  message?: string;
  status: 'pending' | 'in_progress' | 'completed' | 'cancelled' | 'expired';
  signatories: Signatory[];
  completedAt?: Date;
  expiresAt?: Date;
  auditLog: SignatureAuditEntry[];
  createdById: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface Signatory {
  id: string;
  signatureRequestId: string;
  email: string;
  name: string;
  order: number;
  status: 'pending' | 'viewed' | 'signed' | 'declined';
  signedAt?: Date;
  declinedAt?: Date;
  signatureImageUrl?: string;
  ipAddress?: string;
}

export interface SignatureAuditEntry {
  id: string;
  signatureRequestId: string;
  event: string;
  actorEmail?: string;
  ipAddress?: string;
  metadata?: Record<string, unknown>;
  createdAt: Date;
}

// ─── Notifications ───────────────────────────────────────────
export type NotificationType =
  | 'info'
  | 'warning'
  | 'error'
  | 'success'
  | 'action_required';

export interface Notification {
  id: string;
  userId: string;
  tenantId: string;
  type: NotificationType;
  title: string;
  message: string;
  appSlug?: AppSlug;
  actionUrl?: string;
  isRead: boolean;
  createdAt: Date;
}

// ─── API Response Wrappers ────────────────────────────────────
export interface ApiResponse<T> {
  data: T;
  meta?: PaginationMeta;
}

export interface PaginationMeta {
  page: number;
  perPage: number;
  total: number;
  totalPages: number;
}

export interface ApiError {
  statusCode: number;
  message: string;
  errors?: Record<string, string[]>;
}
