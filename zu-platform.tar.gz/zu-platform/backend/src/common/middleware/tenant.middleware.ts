import {
  Injectable,
  NestMiddleware,
  UnauthorizedException,
  ForbiddenException,
} from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Tenant } from '../modules/tenants/entities/tenant.entity';
import { User } from '../modules/users/entities/user.entity';

// Extend Express Request to carry tenant & user context
declare global {
  namespace Express {
    interface Request {
      tenantId?: string;
      tenant?: Tenant;
      currentUser?: User;
    }
  }
}

/**
 * TenantMiddleware
 * ─────────────────────────────────────────────────────────────
 * Resolves the current tenant from the JWT sub-claim or the
 * X-Tenant-ID header (for machine-to-machine requests).
 *
 * All downstream guards and services can trust req.tenantId and
 * req.tenant without making additional DB round-trips.
 */
@Injectable()
export class TenantMiddleware implements NestMiddleware {
  constructor(
    @InjectRepository(Tenant)
    private readonly tenantRepo: Repository<Tenant>,
  ) {}

  async use(req: Request, _res: Response, next: NextFunction) {
    // Public routes – no tenant resolution needed
    const publicPaths = [
      '/api/health',
      '/api/auth/login',
      '/api/auth/register',
      '/api/auth/forgot-password',
      '/api/docs',
      '/api/webhooks',
    ];

    if (publicPaths.some((p) => req.path.startsWith(p))) {
      return next();
    }

    const tenantId =
      (req.headers['x-tenant-id'] as string) ||
      (req as any).user?.tenantId;

    if (!tenantId) {
      return next(); // Auth guard will handle unauthenticated requests
    }

    const tenant = await this.tenantRepo.findOne({
      where: { id: tenantId },
      select: ['id', 'name', 'slug', 'plan', 'subscriptionStatus', 'isActive'],
    });

    if (!tenant) {
      throw new UnauthorizedException('Tenant not found');
    }

    if (!tenant.isActive || tenant.subscriptionStatus === 'suspended') {
      throw new ForbiddenException(
        'Your account has been suspended. Please contact support.',
      );
    }

    req.tenantId = tenant.id;
    req.tenant = tenant;

    return next();
  }
}

/**
 * TenantAwareRepository mixin
 * ─────────────────────────────────────────────────────────────
 * Base helper used by all feature repositories to automatically
 * scope every query to the current tenant.
 */
export function applyTenantScope<T extends { tenantId: string }>(
  tenantId: string,
  query: Record<string, any>,
): Record<string, any> {
  return { ...query, tenantId };
}
