import {
  Injectable, CanActivate, ExecutionContext, ForbiddenException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ApplicationEntitlement } from '../../modules/billing/entities/billing.entities';
import { Tenant } from '../../modules/tenants/entities/tenant.entity';

export const APP_KEY = 'app_slug';
export const RequiresApp = (appSlug: string) =>
  (target: any, key: string, descriptor: PropertyDescriptor) => {
    Reflect.defineMetadata(APP_KEY, appSlug, descriptor.value);
    return descriptor;
  };

@Injectable()
export class EntitlementGuard implements CanActivate {
  constructor(
    private readonly reflector: Reflector,
    @InjectRepository(ApplicationEntitlement)
    private readonly entitlementRepo: Repository<ApplicationEntitlement>,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const appSlug = this.reflector.getAllAndOverride<string>(APP_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);

    if (!appSlug) return true;

    const request = context.switchToHttp().getRequest();
    const tenant: Tenant = request.tenant;

    if (!tenant) {
      throw new ForbiddenException('Tenant context required');
    }

    const entitlement = await this.entitlementRepo.findOne({
      where: { planSlug: tenant.plan, appSlug, enabled: true },
    });

    if (!entitlement) {
      throw new ForbiddenException(
        `Your current plan (${tenant.plan}) does not include access to ${appSlug}. Please upgrade.`,
      );
    }

    return true;
  }
}
