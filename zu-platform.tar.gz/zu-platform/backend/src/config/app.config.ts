import { registerAs } from '@nestjs/config';

export default registerAs('app', () => ({
  nodeEnv:     process.env.NODE_ENV || 'development',
  port:        parseInt(process.env.PORT || '4000', 10),
  frontendUrl: process.env.FRONTEND_URL || 'http://localhost:3000',
  jwtSecret:   process.env.JWT_SECRET || 'dev-secret-change-in-production',
  jwtExpiry:   process.env.JWT_EXPIRY || '7d',
  clerkSecretKey:      process.env.CLERK_SECRET_KEY,
  clerkWebhookSecret:  process.env.CLERK_WEBHOOK_SECRET,
  resendApiKey:        process.env.RESEND_API_KEY,
  stripeSecretKey:     process.env.STRIPE_SECRET_KEY,
  stripeWebhookSecret: process.env.STRIPE_WEBHOOK_SECRET,
}));
