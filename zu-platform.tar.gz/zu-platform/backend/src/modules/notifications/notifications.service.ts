import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ConfigService } from '@nestjs/config';
import { Resend } from 'resend';

export interface CreateNotificationDto {
  userId: string;
  tenantId: string;
  type: 'info' | 'warning' | 'error' | 'success' | 'action_required';
  title: string;
  message: string;
  appSlug?: string;
  actionUrl?: string;
}

// Inline entity definition (in production use a separate entity file)
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, Index } from 'typeorm';

@Entity('notifications')
@Index(['userId', 'isRead'])
export class Notification {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column() userId: string;
  @Column() tenantId: string;
  @Column({ default: 'info' }) type: string;
  @Column() title: string;
  @Column({ type: 'text' }) message: string;
  @Column({ nullable: true }) appSlug: string;
  @Column({ nullable: true }) actionUrl: string;
  @Column({ default: false }) isRead: boolean;
  @CreateDateColumn() createdAt: Date;
}

@Injectable()
export class NotificationsService {
  private resend: Resend;

  constructor(
    @InjectRepository(Notification)
    private readonly notifRepo: Repository<Notification>,
    private readonly configService: ConfigService,
  ) {
    this.resend = new Resend(this.configService.get<string>('RESEND_API_KEY'));
  }

  async create(dto: CreateNotificationDto): Promise<Notification> {
    const notif = this.notifRepo.create(dto);
    return this.notifRepo.save(notif);
  }

  async findForUser(userId: string, tenantId: string) {
    return this.notifRepo.find({
      where: { userId, tenantId },
      order: { createdAt: 'DESC' },
      take: 50,
    });
  }

  async markRead(id: string, userId: string): Promise<void> {
    await this.notifRepo.update({ id, userId }, { isRead: true });
  }

  async markAllRead(userId: string, tenantId: string): Promise<void> {
    await this.notifRepo.update({ userId, tenantId, isRead: false }, { isRead: true });
  }

  async getUnreadCount(userId: string, tenantId: string): Promise<number> {
    return this.notifRepo.count({ where: { userId, tenantId, isRead: false } });
  }

  // ─── Email ─────────────────────────────────────────────────
  async sendEmail(to: string, subject: string, html: string): Promise<void> {
    const from = this.configService.get<string>('EMAIL_FROM', 'no-reply@zuplatform.com');
    const fromName = this.configService.get<string>('EMAIL_FROM_NAME', 'Zu Platform');

    try {
      await this.resend.emails.send({
        from: `${fromName} <${from}>`,
        to,
        subject,
        html,
      });
    } catch (err) {
      console.error('Email send failed:', err);
    }
  }

  async sendWelcomeEmail(to: string, name: string): Promise<void> {
    await this.sendEmail(
      to,
      'Welcome to Zu Platform',
      `
        <h1>Welcome, ${name}!</h1>
        <p>Your Zu Platform account is ready. You have access to:</p>
        <ul>
          <li><strong>ZuCards</strong> – Group eCards for your team</li>
          <li><strong>ZuDoc</strong> – Document management & e-signatures</li>
        </ul>
        <p><a href="${this.configService.get('FRONTEND_URL')}/dashboard">Go to your dashboard →</a></p>
        <p>The Zu Platform team</p>
      `,
    );
  }

  async sendSignatureRequestEmail(
    to: string,
    recipientName: string,
    documentTitle: string,
    signingUrl: string,
  ): Promise<void> {
    await this.sendEmail(
      to,
      `Signature required: ${documentTitle}`,
      `
        <h2>You have a document to sign</h2>
        <p>Hi ${recipientName},</p>
        <p>You've been requested to sign <strong>${documentTitle}</strong>.</p>
        <p><a href="${signingUrl}" style="background:#6366f1;color:white;padding:12px 24px;border-radius:8px;text-decoration:none;display:inline-block">
          Review & Sign
        </a></p>
        <p>This link expires in 30 days.</p>
        <p>Zu Platform</p>
      `,
    );
  }

  async sendCardDeliveryEmail(
    to: string,
    recipientName: string,
    cardUrl: string,
    senderName: string,
  ): Promise<void> {
    await this.sendEmail(
      to,
      `${senderName} sent you a card!`,
      `
        <h2>You have a card waiting for you 🎉</h2>
        <p>Hi ${recipientName},</p>
        <p>${senderName} and your team have put together a card for you.</p>
        <p><a href="${cardUrl}" style="background:#f97316;color:white;padding:12px 24px;border-radius:8px;text-decoration:none;display:inline-block">
          Open your card
        </a></p>
        <p>Zu Platform</p>
      `,
    );
  }
}
