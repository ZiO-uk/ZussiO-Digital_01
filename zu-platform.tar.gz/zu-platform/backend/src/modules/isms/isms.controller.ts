import {
  Controller, Get, Post, Put, Delete, Param, Body, Query,
  UseGuards, Request, HttpCode, HttpStatus,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { IsmsService } from './isms.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { EntitlementGuard } from '../../common/guards/entitlement.guard';
import { RequiresApp } from '../../common/guards/entitlement.guard';

@ApiTags('isms')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard, EntitlementGuard)
@RequiresApp('isms')
@Controller({ path: 'isms', version: '1' })
export class IsmsController {
  constructor(private readonly ismsService: IsmsService) {}

  // ─── Risks ──────────────────────────────────────────────────
  @Get('risks')
  @ApiOperation({ summary: 'Get risk register' })
  getRisks(@Request() req: any, @Query('status') status?: string, @Query('severity') severity?: string) {
    return this.ismsService.getRisks(req.tenantId, { status, severity });
  }

  @Get('risks/matrix')
  @ApiOperation({ summary: 'Get risk matrix' })
  getRiskMatrix(@Request() req: any) {
    return this.ismsService.getRiskMatrix(req.tenantId);
  }

  @Get('risks/:id')
  @ApiOperation({ summary: 'Get risk by ID' })
  getRisk(@Param('id') id: string, @Request() req: any) {
    return this.ismsService.getRisk(req.tenantId, id);
  }

  @Post('risks')
  @ApiOperation({ summary: 'Create risk' })
  createRisk(@Body() body: any, @Request() req: any) {
    return this.ismsService.createRisk(req.tenantId, body);
  }

  @Put('risks/:id')
  @ApiOperation({ summary: 'Update risk' })
  updateRisk(@Param('id') id: string, @Body() body: any, @Request() req: any) {
    return this.ismsService.updateRisk(req.tenantId, id, body);
  }

  @Delete('risks/:id')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Delete risk' })
  deleteRisk(@Param('id') id: string, @Request() req: any) {
    return this.ismsService.deleteRisk(req.tenantId, id);
  }

  // ─── Controls ────────────────────────────────────────────────
  @Get('controls')
  @ApiOperation({ summary: 'Get controls' })
  getControls(@Request() req: any, @Query('framework') framework?: string) {
    return this.ismsService.getControls(req.tenantId, framework);
  }

  @Get('controls/compliance/:framework')
  @ApiOperation({ summary: 'Get compliance summary for framework' })
  getComplianceSummary(@Param('framework') framework: string, @Request() req: any) {
    return this.ismsService.getComplianceSummary(req.tenantId, framework);
  }

  @Put('controls/:id')
  @ApiOperation({ summary: 'Update control' })
  updateControl(@Param('id') id: string, @Body() body: any, @Request() req: any) {
    return this.ismsService.updateControl(req.tenantId, id, body);
  }

  // ─── Policies ────────────────────────────────────────────────
  @Get('policies')
  @ApiOperation({ summary: 'Get policies' })
  getPolicies(@Request() req: any) {
    return this.ismsService.getPolicies(req.tenantId);
  }

  @Post('policies')
  @ApiOperation({ summary: 'Create policy' })
  createPolicy(@Body() body: any, @Request() req: any) {
    return this.ismsService.createPolicy(req.tenantId, { ...body, createdById: req.user.id });
  }

  @Post('policies/:id/approve')
  @ApiOperation({ summary: 'Approve policy' })
  approvePolicy(@Param('id') id: string, @Request() req: any) {
    return this.ismsService.approvePolicy(req.tenantId, id, req.user.id);
  }

  @Post('policies/:id/acknowledge')
  @ApiOperation({ summary: 'Acknowledge policy' })
  acknowledgePolicy(@Param('id') id: string, @Request() req: any) {
    return this.ismsService.acknowledgePolicy(id, req.user.id);
  }

  // ─── Audits ──────────────────────────────────────────────────
  @Get('audits')
  @ApiOperation({ summary: 'Get audits' })
  getAudits(@Request() req: any) {
    return this.ismsService.getAudits(req.tenantId);
  }

  @Post('audits')
  @ApiOperation({ summary: 'Create audit' })
  createAudit(@Body() body: any, @Request() req: any) {
    return this.ismsService.createAudit(req.tenantId, { ...body, createdById: req.user.id });
  }

  @Post('audits/:id/findings')
  @ApiOperation({ summary: 'Add finding to audit' })
  addFinding(@Param('id') id: string, @Body() body: any, @Request() req: any) {
    return this.ismsService.addFinding(id, req.tenantId, body);
  }
}
