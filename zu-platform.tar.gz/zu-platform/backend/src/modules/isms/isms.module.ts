// ─── Module ──────────────────────────────────────────────────
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import {
  IsmsRisk, IsmsControl, IsmsPolicy,
  PolicyAcknowledgement, IsmsAudit, AuditFinding,
} from './entities/isms.entities';
import { IsmsService } from './isms.service';
import { IsmsController } from './isms.controller';
import { BillingModule } from '../billing/billing.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      IsmsRisk, IsmsControl, IsmsPolicy,
      PolicyAcknowledgement, IsmsAudit, AuditFinding,
    ]),
    BillingModule,
  ],
  providers: [IsmsService],
  controllers: [IsmsController],
  exports: [IsmsService],
})
export class IsmsModule {}
