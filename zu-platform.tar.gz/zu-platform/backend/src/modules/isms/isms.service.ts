import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, FindManyOptions } from 'typeorm';
import {
  IsmsRisk, IsmsControl, IsmsPolicy,
  PolicyAcknowledgement, IsmsAudit, AuditFinding,
} from './entities/isms.entities';

@Injectable()
export class IsmsService {
  constructor(
    @InjectRepository(IsmsRisk)        private riskRepo: Repository<IsmsRisk>,
    @InjectRepository(IsmsControl)     private controlRepo: Repository<IsmsControl>,
    @InjectRepository(IsmsPolicy)      private policyRepo: Repository<IsmsPolicy>,
    @InjectRepository(PolicyAcknowledgement) private ackRepo: Repository<PolicyAcknowledgement>,
    @InjectRepository(IsmsAudit)       private auditRepo: Repository<IsmsAudit>,
    @InjectRepository(AuditFinding)    private findingRepo: Repository<AuditFinding>,
  ) {}

  // ─── Risks ──────────────────────────────────────────────────
  async getRisks(tenantId: string, filters?: { status?: string; severity?: string }) {
    const where: any = { tenantId };
    if (filters?.status)   where.status   = filters.status;
    if (filters?.severity) where.severity = filters.severity;
    return this.riskRepo.find({ where, order: { createdAt: 'DESC' } });
  }

  async getRisk(tenantId: string, id: string): Promise<IsmsRisk> {
    const risk = await this.riskRepo.findOne({ where: { id, tenantId } });
    if (!risk) throw new NotFoundException('Risk not found');
    return risk;
  }

  async createRisk(tenantId: string, data: Partial<IsmsRisk>): Promise<IsmsRisk> {
    const risk = this.riskRepo.create({ ...data, tenantId });
    return this.riskRepo.save(risk);
  }

  async updateRisk(tenantId: string, id: string, data: Partial<IsmsRisk>): Promise<IsmsRisk> {
    const risk = await this.getRisk(tenantId, id);
    Object.assign(risk, data);
    return this.riskRepo.save(risk);
  }

  async deleteRisk(tenantId: string, id: string): Promise<void> {
    const risk = await this.getRisk(tenantId, id);
    await this.riskRepo.remove(risk);
  }

  async getRiskMatrix(tenantId: string) {
    const risks = await this.getRisks(tenantId);
    const matrix: Record<string, IsmsRisk[]> = {
      critical: [], high: [], medium: [], low: [],
    };
    risks.forEach((r) => matrix[r.severity]?.push(r));
    return {
      matrix,
      totals: {
        critical: matrix.critical.length,
        high:     matrix.high.length,
        medium:   matrix.medium.length,
        low:      matrix.low.length,
        total:    risks.length,
      },
    };
  }

  // ─── Controls ────────────────────────────────────────────────
  async getControls(tenantId: string, framework?: string) {
    const where: any = { tenantId };
    if (framework) where.framework = framework;
    return this.controlRepo.find({ where, order: { controlRef: 'ASC' } });
  }

  async getControl(tenantId: string, id: string): Promise<IsmsControl> {
    const control = await this.controlRepo.findOne({ where: { id, tenantId } });
    if (!control) throw new NotFoundException('Control not found');
    return control;
  }

  async createControl(tenantId: string, data: Partial<IsmsControl>): Promise<IsmsControl> {
    const control = this.controlRepo.create({ ...data, tenantId });
    return this.controlRepo.save(control);
  }

  async updateControl(tenantId: string, id: string, data: Partial<IsmsControl>): Promise<IsmsControl> {
    const control = await this.getControl(tenantId, id);
    Object.assign(control, data);
    return this.controlRepo.save(control);
  }

  async getComplianceSummary(tenantId: string, framework: string) {
    const controls = await this.getControls(tenantId, framework);
    const total = controls.length;
    const implemented = controls.filter((c) => c.status === 'implemented').length;
    const inProgress  = controls.filter((c) => c.status === 'in_progress').length;
    const notStarted  = controls.filter((c) => c.status === 'not_started').length;
    const notApplicable = controls.filter((c) => c.status === 'not_applicable').length;

    return {
      framework,
      total,
      implemented,
      inProgress,
      notStarted,
      notApplicable,
      compliancePercent: total > 0
        ? Math.round(((implemented + notApplicable) / total) * 100)
        : 0,
    };
  }

  // ─── Policies ────────────────────────────────────────────────
  async getPolicies(tenantId: string) {
    return this.policyRepo.find({
      where: { tenantId },
      order: { createdAt: 'DESC' },
    });
  }

  async getPolicy(tenantId: string, id: string): Promise<IsmsPolicy> {
    const policy = await this.policyRepo.findOne({
      where: { id, tenantId },
      relations: ['acknowledgements', 'acknowledgements.user'],
    });
    if (!policy) throw new NotFoundException('Policy not found');
    return policy;
  }

  async createPolicy(tenantId: string, data: Partial<IsmsPolicy>): Promise<IsmsPolicy> {
    const policy = this.policyRepo.create({ ...data, tenantId, version: '1.0' });
    return this.policyRepo.save(policy);
  }

  async approvePolicy(tenantId: string, id: string, approvedById: string): Promise<IsmsPolicy> {
    const policy = await this.getPolicy(tenantId, id);
    policy.status = 'approved';
    policy.approvedById = approvedById;
    policy.approvedAt = new Date();
    return this.policyRepo.save(policy);
  }

  async acknowledgePolicy(policyId: string, userId: string): Promise<PolicyAcknowledgement> {
    const existing = await this.ackRepo.findOne({ where: { policyId, userId } });
    if (existing) return existing;

    const ack = this.ackRepo.create({ policyId, userId });
    return this.ackRepo.save(ack);
  }

  // ─── Audits ──────────────────────────────────────────────────
  async getAudits(tenantId: string) {
    return this.auditRepo.find({
      where: { tenantId },
      relations: ['findings'],
      order: { createdAt: 'DESC' },
    });
  }

  async getAudit(tenantId: string, id: string): Promise<IsmsAudit> {
    const audit = await this.auditRepo.findOne({
      where: { id, tenantId },
      relations: ['findings'],
    });
    if (!audit) throw new NotFoundException('Audit not found');
    return audit;
  }

  async createAudit(tenantId: string, data: Partial<IsmsAudit>): Promise<IsmsAudit> {
    const audit = this.auditRepo.create({ ...data, tenantId });
    return this.auditRepo.save(audit);
  }

  async addFinding(auditId: string, tenantId: string, data: Partial<AuditFinding>): Promise<AuditFinding> {
    await this.getAudit(tenantId, auditId); // verify ownership
    const finding = this.findingRepo.create({ ...data, auditId });
    return this.findingRepo.save(finding);
  }
}
