import {
  Entity, PrimaryGeneratedColumn, Column, CreateDateColumn,
  UpdateDateColumn, ManyToOne, JoinColumn, OneToMany, Index,
} from 'typeorm';
import { User } from '../../users/entities/user.entity';

// ─── Risk ─────────────────────────────────────────────────────
@Entity('isms_risks')
@Index(['tenantId'])
export class IsmsRisk {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  tenantId: string;

  @Column()
  title: string;

  @Column({ type: 'text' })
  description: string;

  @Column({ type: 'int' })
  likelihood: number; // 1-5

  @Column({ type: 'int' })
  impact: number; // 1-5

  @Column({ type: 'int', generatedType: 'STORED',
    asExpression: '"likelihood" * "impact"' })
  riskScore: number;

  @Column({
    generatedType: 'STORED',
    asExpression: `
      CASE
        WHEN "likelihood" * "impact" >= 20 THEN 'critical'
        WHEN "likelihood" * "impact" >= 15 THEN 'high'
        WHEN "likelihood" * "impact" >= 8  THEN 'medium'
        ELSE 'low'
      END
    `,
  })
  severity: string;

  @Column({ default: 'open' })
  status: string; // open | in_treatment | accepted | closed

  @Column({ nullable: true })
  ownerId: string;

  @ManyToOne(() => User, { nullable: true })
  @JoinColumn({ name: 'ownerId' })
  owner: User;

  @Column({ type: 'text', nullable: true })
  treatmentPlan: string;

  @Column({ nullable: true })
  dueDate: Date;

  @Column({ type: 'text', array: true, default: '{}' })
  tags: string[];

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}

// ─── Control ──────────────────────────────────────────────────
@Entity('isms_controls')
@Index(['tenantId', 'framework'])
export class IsmsControl {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  tenantId: string;

  @Column()
  framework: string; // iso27001 | cyber_essentials | gdpr

  @Column()
  controlRef: string; // e.g. A.5.1

  @Column()
  title: string;

  @Column({ type: 'text' })
  description: string;

  @Column({ default: 'not_started' })
  status: string; // not_started | in_progress | implemented | not_applicable

  @Column({ nullable: true })
  ownerId: string;

  @ManyToOne(() => User, { nullable: true })
  @JoinColumn({ name: 'ownerId' })
  owner: User;

  @Column({ nullable: true })
  lastReviewedAt: Date;

  @Column({ nullable: true })
  nextReviewAt: Date;

  @Column({ type: 'text', nullable: true })
  notes: string;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}

// ─── Policy ───────────────────────────────────────────────────
@Entity('isms_policies')
@Index(['tenantId'])
export class IsmsPolicy {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  tenantId: string;

  @Column()
  title: string;

  @Column({ type: 'text' })
  content: string;

  @Column({ default: '1.0' })
  version: string;

  @Column({ default: 'draft' })
  status: string; // draft | pending_approval | approved | archived

  @Column({ nullable: true })
  approvedById: string;

  @ManyToOne(() => User, { nullable: true })
  @JoinColumn({ name: 'approvedById' })
  approvedBy: User;

  @Column({ nullable: true })
  approvedAt: Date;

  @Column({ nullable: true })
  reviewDate: Date;

  @OneToMany(() => PolicyAcknowledgement, (a) => a.policy, { cascade: true })
  acknowledgements: PolicyAcknowledgement[];

  @Column()
  createdById: string;

  @ManyToOne(() => User)
  @JoinColumn({ name: 'createdById' })
  createdBy: User;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}

@Entity('policy_acknowledgements')
export class PolicyAcknowledgement {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  policyId: string;

  @ManyToOne(() => IsmsPolicy, (p) => p.acknowledgements, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'policyId' })
  policy: IsmsPolicy;

  @Column()
  userId: string;

  @ManyToOne(() => User)
  @JoinColumn({ name: 'userId' })
  user: User;

  @CreateDateColumn()
  acknowledgedAt: Date;
}

// ─── Audit ────────────────────────────────────────────────────
@Entity('isms_audits')
@Index(['tenantId'])
export class IsmsAudit {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  tenantId: string;

  @Column()
  title: string;

  @Column({ type: 'text', nullable: true })
  scope: string;

  @Column({ default: 'planned' })
  status: string; // planned | in_progress | completed | cancelled

  @Column({ nullable: true })
  scheduledDate: Date;

  @Column({ nullable: true })
  completedDate: Date;

  @Column({ nullable: true })
  auditorId: string;

  @ManyToOne(() => User, { nullable: true })
  @JoinColumn({ name: 'auditorId' })
  auditor: User;

  @OneToMany(() => AuditFinding, (f) => f.audit, { cascade: true })
  findings: AuditFinding[];

  @Column()
  createdById: string;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}

@Entity('audit_findings')
export class AuditFinding {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  auditId: string;

  @ManyToOne(() => IsmsAudit, (a) => a.findings, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'auditId' })
  audit: IsmsAudit;

  @Column()
  title: string;

  @Column({ type: 'text' })
  description: string;

  @Column({ default: 'minor' })
  severity: string; // minor | major | critical | observation

  @Column({ default: 'open' })
  status: string; // open | in_progress | closed

  @Column({ nullable: true })
  dueDate: Date;

  @Column({ nullable: true })
  correctiveAction: string;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
