import {
  Entity, PrimaryGeneratedColumn, Column, CreateDateColumn,
  UpdateDateColumn, OneToMany, Index,
} from 'typeorm';

export type PlanSlug = 'free' | 'silver' | 'gold' | 'enterprise';
export type SubscriptionStatus =
  | 'trial' | 'active' | 'past_due' | 'suspended' | 'cancelled' | 'expired';

@Entity('tenants')
@Index(['slug'], { unique: true })
export class Tenant {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ length: 255 })
  name: string;

  @Column({ unique: true, length: 100 })
  slug: string;

  @Column({ nullable: true })
  logoUrl: string;

  @Column({ nullable: true, length: 7 })
  primaryColour: string;

  @Column({ default: 'free' })
  plan: PlanSlug;

  @Column({ default: 'trial' })
  subscriptionStatus: SubscriptionStatus;

  @Column({ nullable: true })
  stripeCustomerId: string;

  @Column({ nullable: true })
  stripeSubscriptionId: string;

  @Column({ nullable: true })
  trialEndsAt: Date;

  @Column({ default: 0 })
  userCount: number;

  @Column({ type: 'bigint', default: 0 })
  storageUsedBytes: number;

  @Column({ type: 'bigint', default: 5368709120 }) // 5 GB
  storageLimitBytes: number;

  @Column({ default: true })
  isActive: boolean;

  @Column({ nullable: true })
  billingEmail: string;

  @Column({ nullable: true })
  billingAddressLine1: string;

  @Column({ nullable: true })
  billingCity: string;

  @Column({ nullable: true })
  billingPostcode: string;

  @Column({ nullable: true, default: 'GB' })
  billingCountry: string;

  @Column({ nullable: true })
  vatNumber: string;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
