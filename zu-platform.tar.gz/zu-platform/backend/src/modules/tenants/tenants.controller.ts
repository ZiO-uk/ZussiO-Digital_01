import {
  Controller, Get, Post, Patch, Param, Body, Query,
  UseGuards, HttpCode, HttpStatus, Request,
} from '@nestjs/common';
import {
  ApiTags, ApiOperation, ApiBearerAuth, ApiQuery,
} from '@nestjs/swagger';
import { TenantsService } from './tenants.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';

@ApiTags('tenants')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller({ path: 'tenants', version: '1' })
export class TenantsController {
  constructor(private readonly tenantsService: TenantsService) {}

  @Get()
  @Roles('super_admin', 'platform_manager')
  @ApiOperation({ summary: 'List all tenants (admin only)' })
  @ApiQuery({ name: 'page', required: false, type: Number })
  @ApiQuery({ name: 'perPage', required: false, type: Number })
  findAll(@Query('page') page?: number, @Query('perPage') perPage?: number) {
    return this.tenantsService.findAll({ page, perPage });
  }

  @Get('me')
  @ApiOperation({ summary: 'Get current tenant' })
  async findMine(@Request() req: any) {
    return this.tenantsService.findById(req.tenantId);
  }

  @Get(':id')
  @Roles('super_admin', 'platform_manager')
  @ApiOperation({ summary: 'Get tenant by ID' })
  findOne(@Param('id') id: string) {
    return this.tenantsService.findById(id);
  }

  @Patch(':id')
  @Roles('super_admin', 'platform_manager', 'tenant_admin')
  @ApiOperation({ summary: 'Update tenant' })
  update(@Param('id') id: string, @Body() dto: any) {
    return this.tenantsService.update(id, dto);
  }

  @Post(':id/suspend')
  @Roles('super_admin', 'platform_manager')
  @ApiOperation({ summary: 'Suspend tenant' })
  @HttpCode(HttpStatus.OK)
  suspend(@Param('id') id: string) {
    return this.tenantsService.suspend(id);
  }

  @Post(':id/activate')
  @Roles('super_admin', 'platform_manager')
  @ApiOperation({ summary: 'Activate tenant' })
  @HttpCode(HttpStatus.OK)
  activate(@Param('id') id: string) {
    return this.tenantsService.activate(id);
  }
}
