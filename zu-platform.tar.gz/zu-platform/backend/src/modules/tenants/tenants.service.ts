import { Injectable, NotFoundException, ConflictException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Tenant } from './entities/tenant.entity';
import { slugify } from '../../common/utils/slug.util';

@Injectable()
export class TenantsService {
  constructor(
    @InjectRepository(Tenant)
    private readonly tenantRepo: Repository<Tenant>,
  ) {}

  async create(data: {
    name: string;
    billingEmail: string;
    plan?: string;
  }): Promise<Tenant> {
    const slug = await this.generateUniqueSlug(data.name);

    const existing = await this.tenantRepo.findOne({ where: { slug } });
    if (existing) {
      throw new ConflictException(`Tenant with slug "${slug}" already exists`);
    }

    const tenant = this.tenantRepo.create({
      name: data.name,
      slug,
      billingEmail: data.billingEmail,
      plan: (data.plan as any) || 'free',
      subscriptionStatus: 'trial',
      trialEndsAt: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000), // 14 days
    });

    return this.tenantRepo.save(tenant);
  }

  async findById(id: string): Promise<Tenant> {
    const tenant = await this.tenantRepo.findOne({ where: { id } });
    if (!tenant) throw new NotFoundException(`Tenant ${id} not found`);
    return tenant;
  }

  async findBySlug(slug: string): Promise<Tenant> {
    const tenant = await this.tenantRepo.findOne({ where: { slug } });
    if (!tenant) throw new NotFoundException(`Tenant ${slug} not found`);
    return tenant;
  }

  async findAll(opts?: { page?: number; perPage?: number }) {
    const page = opts?.page ?? 1;
    const perPage = opts?.perPage ?? 20;

    const [items, total] = await this.tenantRepo.findAndCount({
      order: { createdAt: 'DESC' },
      skip: (page - 1) * perPage,
      take: perPage,
    });

    return { items, total, page, perPage };
  }

  async update(id: string, data: Partial<Tenant>): Promise<Tenant> {
    const tenant = await this.findById(id);
    Object.assign(tenant, data);
    return this.tenantRepo.save(tenant);
  }

  async suspend(id: string): Promise<Tenant> {
    return this.update(id, { subscriptionStatus: 'suspended', isActive: false });
  }

  async activate(id: string): Promise<Tenant> {
    return this.update(id, { subscriptionStatus: 'active', isActive: true });
  }

  async incrementUserCount(id: string): Promise<void> {
    await this.tenantRepo.increment({ id }, 'userCount', 1);
  }

  async decrementUserCount(id: string): Promise<void> {
    await this.tenantRepo.decrement({ id }, 'userCount', 1);
  }

  async updateStorageUsage(id: string, bytes: number): Promise<void> {
    await this.tenantRepo.update(id, { storageUsedBytes: bytes });
  }

  private async generateUniqueSlug(name: string): Promise<string> {
    const base = slugify(name);
    let slug = base;
    let i = 1;

    while (await this.tenantRepo.findOne({ where: { slug } })) {
      slug = `${base}-${i++}`;
    }

    return slug;
  }
}
