import {
  Injectable, NotFoundException, ConflictException, BadRequestException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import {
  SubscriptionPlan, TenantSubscription, ApplicationEntitlement,
  FeatureFlag, Invoice, UsageRecord,
} from './entities/billing.entities';
import { TenantsService } from '../tenants/tenants.service';

@Injectable()
export class BillingService {
  constructor(
    @InjectRepository(SubscriptionPlan)
    private readonly planRepo: Repository<SubscriptionPlan>,
    @InjectRepository(TenantSubscription)
    private readonly subscriptionRepo: Repository<TenantSubscription>,
    @InjectRepository(ApplicationEntitlement)
    private readonly entitlementRepo: Repository<ApplicationEntitlement>,
    @InjectRepository(FeatureFlag)
    private readonly featureFlagRepo: Repository<FeatureFlag>,
    @InjectRepository(Invoice)
    private readonly invoiceRepo: Repository<Invoice>,
    @InjectRepository(UsageRecord)
    private readonly usageRepo: Repository<UsageRecord>,
    private readonly tenantsService: TenantsService,
  ) {}

  // ─── Plans ──────────────────────────────────────────────────
  async getPublicPlans(): Promise<SubscriptionPlan[]> {
    return this.planRepo.find({
      where: { isPublic: true, isActive: true },
      order: { sortOrder: 'ASC' },
    });
  }

  async getPlanBySlug(slug: string): Promise<SubscriptionPlan> {
    const plan = await this.planRepo.findOne({ where: { slug } });
    if (!plan) throw new NotFoundException(`Plan ${slug} not found`);
    return plan;
  }

  // ─── Entitlements ────────────────────────────────────────────
  async checkAppEntitlement(planSlug: string, appSlug: string): Promise<boolean> {
    const entitlement = await this.entitlementRepo.findOne({
      where: { planSlug, appSlug, enabled: true },
    });
    return !!entitlement;
  }

  async getEntitlementsForPlan(planSlug: string): Promise<ApplicationEntitlement[]> {
    return this.entitlementRepo.find({ where: { planSlug } });
  }

  async checkFeatureFlag(planSlug: string, featureKey: string): Promise<boolean> {
    const flag = await this.featureFlagRepo.findOne({
      where: { planSlug, key: featureKey, enabled: true },
    });
    return !!flag;
  }

  // ─── Subscriptions ───────────────────────────────────────────
  async getSubscription(tenantId: string): Promise<TenantSubscription | null> {
    return this.subscriptionRepo.findOne({ where: { tenantId } });
  }

  async createOrUpdateSubscription(
    tenantId: string,
    planSlug: string,
    stripeData?: { subscriptionId?: string; periodStart?: Date; periodEnd?: Date },
  ): Promise<TenantSubscription> {
    let sub = await this.subscriptionRepo.findOne({ where: { tenantId } });

    if (!sub) {
      sub = this.subscriptionRepo.create({ tenantId });
    }

    sub.planSlug = planSlug;
    sub.status = 'active';
    if (stripeData?.subscriptionId) sub.stripeSubscriptionId = stripeData.subscriptionId;
    if (stripeData?.periodStart) sub.currentPeriodStart = stripeData.periodStart;
    if (stripeData?.periodEnd) sub.currentPeriodEnd = stripeData.periodEnd;

    await this.subscriptionRepo.save(sub);
    await this.tenantsService.update(tenantId, {
      plan: planSlug as any,
      subscriptionStatus: 'active',
    });

    return sub;
  }

  async cancelSubscription(tenantId: string): Promise<TenantSubscription> {
    const sub = await this.getSubscription(tenantId);
    if (!sub) throw new NotFoundException('No active subscription found');

    sub.status = 'cancelled';
    sub.cancelledAt = new Date();
    await this.subscriptionRepo.save(sub);
    await this.tenantsService.update(tenantId, { subscriptionStatus: 'cancelled' });

    return sub;
  }

  // ─── Invoices ────────────────────────────────────────────────
  async getInvoices(tenantId: string) {
    return this.invoiceRepo.find({
      where: { tenantId },
      order: { createdAt: 'DESC' },
    });
  }

  async createInvoice(data: Partial<Invoice>): Promise<Invoice> {
    const invoice = this.invoiceRepo.create(data);
    // Generate invoice number
    const count = await this.invoiceRepo.count({ where: { tenantId: data.tenantId } });
    invoice.number = `INV-${new Date().getFullYear()}-${String(count + 1).padStart(4, '0')}`;
    return this.invoiceRepo.save(invoice);
  }

  // ─── Usage ───────────────────────────────────────────────────
  async recordUsage(tenantId: string, metricKey: string, value: number): Promise<void> {
    const record = this.usageRepo.create({
      tenantId,
      metricKey,
      value,
      recordedAt: new Date(),
    });
    await this.usageRepo.save(record);
  }

  async getUsageSummary(tenantId: string) {
    const tenant = await this.tenantsService.findById(tenantId);

    return {
      plan: tenant.plan,
      userCount: tenant.userCount,
      storageUsedBytes: tenant.storageUsedBytes,
      storageLimitBytes: tenant.storageLimitBytes,
      storageUsedPercent: Math.round(
        (Number(tenant.storageUsedBytes) / Number(tenant.storageLimitBytes)) * 100,
      ),
    };
  }
}
