import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import {
  SubscriptionPlan, TenantSubscription, ApplicationEntitlement,
  FeatureFlag, Invoice, UsageRecord,
} from './entities/billing.entities';
import { BillingService } from './billing.service';
import { BillingController } from './billing.controller';
import { TenantsModule } from '../tenants/tenants.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      SubscriptionPlan, TenantSubscription, ApplicationEntitlement,
      FeatureFlag, Invoice, UsageRecord,
    ]),
    TenantsModule,
  ],
  providers: [BillingService],
  controllers: [BillingController],
  exports: [BillingService, TypeOrmModule],
})
export class BillingModule {}
