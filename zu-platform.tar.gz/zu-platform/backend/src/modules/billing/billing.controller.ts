import {
  Controller, Get, Post, Param, Body, Request, UseGuards,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { BillingService } from './billing.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';

@ApiTags('billing')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller({ path: 'billing', version: '1' })
export class BillingController {
  constructor(private readonly billingService: BillingService) {}

  @Get('plans')
  @ApiOperation({ summary: 'Get all public subscription plans' })
  getPlans() {
    return this.billingService.getPublicPlans();
  }

  @Get('subscription')
  @ApiOperation({ summary: 'Get current tenant subscription' })
  getSubscription(@Request() req: any) {
    return this.billingService.getSubscription(req.tenantId);
  }

  @Get('invoices')
  @ApiOperation({ summary: 'Get tenant invoices' })
  getInvoices(@Request() req: any) {
    return this.billingService.getInvoices(req.tenantId);
  }

  @Get('usage')
  @ApiOperation({ summary: 'Get tenant usage summary' })
  getUsage(@Request() req: any) {
    return this.billingService.getUsageSummary(req.tenantId);
  }

  @Post('subscription/cancel')
  @Roles('tenant_admin', 'super_admin')
  @ApiOperation({ summary: 'Cancel subscription' })
  cancelSubscription(@Request() req: any) {
    return this.billingService.cancelSubscription(req.tenantId);
  }

  @Get('entitlements/:planSlug')
  @ApiOperation({ summary: 'Get entitlements for a plan' })
  getEntitlements(@Param('planSlug') planSlug: string) {
    return this.billingService.getEntitlementsForPlan(planSlug);
  }
}
