import {
  Entity, PrimaryGeneratedColumn, Column, CreateDateColumn,
  UpdateDateColumn, ManyToOne, JoinColumn, Index,
} from 'typeorm';
import { Tenant } from '../../tenants/entities/tenant.entity';

// ─── Subscription Plan ───────────────────────────────────────
@Entity('subscription_plans')
export class SubscriptionPlan {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ unique: true })
  slug: string; // free | silver | gold | enterprise

  @Column()
  name: string;

  @Column({ type: 'text', nullable: true })
  description: string;

  @Column({ type: 'numeric', precision: 10, scale: 2, nullable: true })
  priceMonthlyGbp: number;

  @Column({ type: 'numeric', precision: 10, scale: 2, nullable: true })
  priceAnnualGbp: number;

  @Column({ type: 'jsonb', default: '[]' })
  features: string[];

  @Column({ type: 'jsonb', default: '{}' })
  limits: Record<string, any>;

  @Column({ default: true })
  isPublic: boolean;

  @Column({ default: true })
  isActive: boolean;

  @Column({ default: 0 })
  sortOrder: number;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}

// ─── Tenant Subscription ─────────────────────────────────────
@Entity('tenant_subscriptions')
@Index(['tenantId'], { unique: true })
export class TenantSubscription {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  tenantId: string;

  @ManyToOne(() => Tenant, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'tenantId' })
  tenant: Tenant;

  @Column()
  planSlug: string;

  @Column({ default: 'trial' })
  status: string;

  @Column({ nullable: true })
  stripeSubscriptionId: string;

  @Column({ nullable: true })
  currentPeriodStart: Date;

  @Column({ nullable: true })
  currentPeriodEnd: Date;

  @Column({ nullable: true })
  cancelAtPeriodEnd: boolean;

  @Column({ nullable: true })
  cancelledAt: Date;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}

// ─── Application Entitlement ─────────────────────────────────
@Entity('application_entitlements')
export class ApplicationEntitlement {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  planSlug: string;

  @Column()
  appSlug: string; // isms | zucards | zudoc

  @Column({ default: true })
  enabled: boolean;

  @CreateDateColumn()
  createdAt: Date;
}

// ─── Feature Flag ─────────────────────────────────────────────
@Entity('feature_flags')
export class FeatureFlag {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  key: string; // e.g. isms.compliance_reporting

  @Column()
  appSlug: string;

  @Column()
  planSlug: string;

  @Column({ default: true })
  enabled: boolean;

  @Column({ nullable: true })
  description: string;

  @CreateDateColumn()
  createdAt: Date;
}

// ─── Invoice ──────────────────────────────────────────────────
@Entity('invoices')
@Index(['tenantId'])
export class Invoice {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  tenantId: string;

  @ManyToOne(() => Tenant, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'tenantId' })
  tenant: Tenant;

  @Column({ unique: true })
  number: string; // INV-2024-0001

  @Column({ nullable: true })
  stripeInvoiceId: string;

  @Column({ default: 'draft' })
  status: string; // draft | open | paid | void | uncollectible

  @Column({ type: 'numeric', precision: 10, scale: 2, default: 0 })
  subtotalGbp: number;

  @Column({ type: 'numeric', precision: 10, scale: 2, default: 0 })
  taxAmountGbp: number;

  @Column({ type: 'numeric', precision: 10, scale: 2, default: 0 })
  totalGbp: number;

  @Column({ nullable: true })
  billingPeriodStart: Date;

  @Column({ nullable: true })
  billingPeriodEnd: Date;

  @Column({ nullable: true })
  dueDate: Date;

  @Column({ nullable: true })
  paidAt: Date;

  @Column({ nullable: true })
  pdfUrl: string;

  @Column({ type: 'jsonb', default: '[]' })
  lineItems: Array<{
    description: string;
    quantity: number;
    unitPriceGbp: number;
    totalGbp: number;
  }>;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}

// ─── Usage Record ─────────────────────────────────────────────
@Entity('usage_records')
@Index(['tenantId', 'metricKey', 'recordedAt'])
export class UsageRecord {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  tenantId: string;

  @Column()
  metricKey: string; // users | storage_bytes | documents | cards | signatures | api_calls

  @Column({ type: 'bigint' })
  value: number;

  @Column()
  recordedAt: Date;

  @CreateDateColumn()
  createdAt: Date;
}
