import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import {
  Document, DocumentFolder, DocumentVersion,
  SharedLink, SignatureRequest, Signatory, SignatureAuditEntry,
} from './entities/zudoc.entities';
import { NotificationsService } from '../notifications/notifications.service';
import { ConfigService } from '@nestjs/config';
import { v4 as uuid } from 'uuid';

@Injectable()
export class ZuDocService {
  constructor(
    @InjectRepository(Document)           private docRepo: Repository<Document>,
    @InjectRepository(DocumentFolder)     private folderRepo: Repository<DocumentFolder>,
    @InjectRepository(DocumentVersion)    private versionRepo: Repository<DocumentVersion>,
    @InjectRepository(SharedLink)         private sharedLinkRepo: Repository<SharedLink>,
    @InjectRepository(SignatureRequest)   private sigReqRepo: Repository<SignatureRequest>,
    @InjectRepository(Signatory)          private signatoryRepo: Repository<Signatory>,
    @InjectRepository(SignatureAuditEntry) private auditRepo: Repository<SignatureAuditEntry>,
    private readonly notifService: NotificationsService,
    private readonly configService: ConfigService,
  ) {}

  // ─── Folders ────────────────────────────────────────────────
  async getFolders(tenantId: string) {
    return this.folderRepo.find({ where: { tenantId }, order: { name: 'ASC' } });
  }

  async createFolder(tenantId: string, createdById: string, data: any) {
    const folder = this.folderRepo.create({ ...data, tenantId, createdById });
    return this.folderRepo.save(folder);
  }

  // ─── Documents ──────────────────────────────────────────────
  async getDocuments(tenantId: string, folderId?: string) {
    const where: any = { tenantId };
    if (folderId) where.folderId = folderId;
    return this.docRepo.find({ where, order: { updatedAt: 'DESC' } });
  }

  async getDocument(tenantId: string, id: string): Promise<Document> {
    const doc = await this.docRepo.findOne({
      where: { id, tenantId },
      relations: ['versions', 'sharedLinks', 'signatureRequests'],
    });
    if (!doc) throw new NotFoundException('Document not found');
    return doc;
  }

  async createDocument(tenantId: string, createdById: string, data: any): Promise<Document> {
    const doc = this.docRepo.create({ ...data, tenantId, createdById, status: 'draft' });
    const saved = await this.docRepo.save(doc);

    // Create initial version
    await this.versionRepo.save(
      this.versionRepo.create({
        documentId: saved.id,
        version: 1,
        content: data.content || '',
        changedById: createdById,
        changeSummary: 'Initial version',
      }),
    );

    return saved;
  }

  async updateDocument(tenantId: string, id: string, userId: string, data: any): Promise<Document> {
    const doc = await this.getDocument(tenantId, id);
    const prevContent = doc.content;

    Object.assign(doc, data);
    doc.currentVersion = doc.currentVersion + 1;

    const saved = await this.docRepo.save(doc);

    // Save version snapshot
    await this.versionRepo.save(
      this.versionRepo.create({
        documentId: id,
        version: doc.currentVersion,
        content: data.content || prevContent,
        changedById: userId,
        changeSummary: data.changeSummary,
      }),
    );

    return saved;
  }

  async deleteDocument(tenantId: string, id: string): Promise<void> {
    const doc = await this.getDocument(tenantId, id);
    await this.docRepo.remove(doc);
  }

  // ─── Shared Links ────────────────────────────────────────────
  async createSharedLink(tenantId: string, documentId: string, data: any): Promise<SharedLink> {
    await this.getDocument(tenantId, documentId); // verify ownership
    const link = this.sharedLinkRepo.create({
      documentId,
      token: uuid().replace(/-/g, '').substring(0, 32),
      permissions: data.permissions || 'view',
      expiresAt: data.expiresAt,
    });
    return this.sharedLinkRepo.save(link);
  }

  async getDocumentBySharedToken(token: string): Promise<Document> {
    const link = await this.sharedLinkRepo.findOne({
      where: { token, isActive: true },
      relations: ['document'],
    });
    if (!link) throw new NotFoundException('Shared link not found or expired');
    if (link.expiresAt && link.expiresAt < new Date()) {
      throw new BadRequestException('This shared link has expired');
    }
    return link.document;
  }

  // ─── Signature Requests ──────────────────────────────────────
  async createSignatureRequest(tenantId: string, createdById: string, data: any): Promise<SignatureRequest> {
    await this.getDocument(tenantId, data.documentId);

    const req = this.sigReqRepo.create({
      ...data,
      tenantId,
      createdById,
      status: 'pending',
      expiresAt: data.expiresAt || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days
    });

    const saved = await this.sigReqRepo.save(req);

    // Create signatories and send emails
    if (data.signatories?.length) {
      for (let i = 0; i < data.signatories.length; i++) {
        const s = data.signatories[i];
        const token = uuid().replace(/-/g, '').substring(0, 32);
        const frontendUrl = this.configService.get<string>('FRONTEND_URL', 'http://localhost:3000');

        await this.signatoryRepo.save(
          this.signatoryRepo.create({
            signatureRequestId: saved.id,
            email: s.email,
            name: s.name,
            order: i + 1,
            signingToken: token,
          }),
        );

        // Notify first signatory (sequential signing)
        if (i === 0) {
          const signingUrl = `${frontendUrl}/sign/${token}`;
          await this.notifService.sendSignatureRequestEmail(
            s.email, s.name, data.title, signingUrl,
          );
        }
      }

      saved.status = 'in_progress';
      await this.sigReqRepo.save(saved);
    }

    await this.auditRepo.save(
      this.auditRepo.create({
        signatureRequestId: saved.id,
        event: 'created',
        actorEmail: createdById,
        metadata: { signatoryCount: data.signatories?.length || 0 },
      }),
    );

    return saved;
  }

  async getSignatureRequests(tenantId: string) {
    return this.sigReqRepo.find({
      where: { tenantId },
      relations: ['signatories', 'document'],
      order: { createdAt: 'DESC' },
    });
  }

  async signDocument(token: string, signatureData: string, ipAddress: string): Promise<Signatory> {
    const signatory = await this.signatoryRepo.findOne({
      where: { signingToken: token },
      relations: ['signatureRequest'],
    });

    if (!signatory) throw new NotFoundException('Invalid signing token');
    if (signatory.status !== 'pending') {
      throw new BadRequestException('This signature request has already been actioned');
    }

    signatory.status = 'signed';
    signatory.signedAt = new Date();
    signatory.signatureImageUrl = signatureData;
    signatory.ipAddress = ipAddress;
    await this.signatoryRepo.save(signatory);

    // Audit
    await this.auditRepo.save(
      this.auditRepo.create({
        signatureRequestId: signatory.signatureRequestId,
        event: 'signed',
        actorEmail: signatory.email,
        ipAddress,
      }),
    );

    // Check if all signed
    const allSignatories = await this.signatoryRepo.find({
      where: { signatureRequestId: signatory.signatureRequestId },
    });

    const allSigned = allSignatories.every((s) => s.status === 'signed');
    if (allSigned) {
      await this.sigReqRepo.update(signatory.signatureRequestId, {
        status: 'completed',
        completedAt: new Date(),
      });
    } else {
      // Notify next signatory
      const nextSignatory = allSignatories
        .filter((s) => s.status === 'pending')
        .sort((a, b) => a.order - b.order)[0];

      if (nextSignatory) {
        const frontendUrl = this.configService.get<string>('FRONTEND_URL', 'http://localhost:3000');
        const signingUrl = `${frontendUrl}/sign/${nextSignatory.signingToken}`;
        await this.notifService.sendSignatureRequestEmail(
          nextSignatory.email,
          nextSignatory.name,
          signatory.signatureRequest.title,
          signingUrl,
        );
      }
    }

    return signatory;
  }
}
