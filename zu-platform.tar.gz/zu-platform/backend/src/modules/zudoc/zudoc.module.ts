import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import {
  Document, DocumentFolder, DocumentVersion,
  SharedLink, SignatureRequest, Signatory, SignatureAuditEntry,
} from './entities/zudoc.entities';
import { ZuDocService } from './zudoc.service';
import { ZuDocController } from './zudoc.controller';
import { NotificationsModule } from '../notifications/notifications.module';
import { BillingModule } from '../billing/billing.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      Document, DocumentFolder, DocumentVersion,
      SharedLink, SignatureRequest, Signatory, SignatureAuditEntry,
    ]),
    NotificationsModule,
    BillingModule,
  ],
  providers: [ZuDocService],
  controllers: [ZuDocController],
  exports: [ZuDocService],
})
export class ZuDocModule {}
