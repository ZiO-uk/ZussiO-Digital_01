import {
  Controller, Get, Post, Put, Delete, Param, Body, Query,
  UseGuards, Request, HttpCode, HttpStatus, Ip,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { ZuDocService } from './zudoc.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { Public } from '../../common/decorators/public.decorator';

@ApiTags('zudoc')
@ApiBearerAuth()
@Controller({ path: 'zudoc', version: '1' })
export class ZuDocController {
  constructor(private readonly zuDocService: ZuDocService) {}

  // ─── Folders ────────────────────────────────────────────────
  @Get('folders')
  @UseGuards(JwtAuthGuard)
  @ApiOperation({ summary: 'Get folders' })
  getFolders(@Request() req: any) {
    return this.zuDocService.getFolders(req.tenantId);
  }

  @Post('folders')
  @UseGuards(JwtAuthGuard)
  @ApiOperation({ summary: 'Create folder' })
  createFolder(@Body() body: any, @Request() req: any) {
    return this.zuDocService.createFolder(req.tenantId, req.user.id, body);
  }

  // ─── Documents ──────────────────────────────────────────────
  @Get('documents')
  @UseGuards(JwtAuthGuard)
  @ApiOperation({ summary: 'List documents' })
  getDocuments(@Request() req: any, @Query('folderId') folderId?: string) {
    return this.zuDocService.getDocuments(req.tenantId, folderId);
  }

  @Get('documents/:id')
  @UseGuards(JwtAuthGuard)
  @ApiOperation({ summary: 'Get document' })
  getDocument(@Param('id') id: string, @Request() req: any) {
    return this.zuDocService.getDocument(req.tenantId, id);
  }

  @Post('documents')
  @UseGuards(JwtAuthGuard)
  @ApiOperation({ summary: 'Create document' })
  createDocument(@Body() body: any, @Request() req: any) {
    return this.zuDocService.createDocument(req.tenantId, req.user.id, body);
  }

  @Put('documents/:id')
  @UseGuards(JwtAuthGuard)
  @ApiOperation({ summary: 'Update document' })
  updateDocument(@Param('id') id: string, @Body() body: any, @Request() req: any) {
    return this.zuDocService.updateDocument(req.tenantId, id, req.user.id, body);
  }

  @Delete('documents/:id')
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Delete document' })
  deleteDocument(@Param('id') id: string, @Request() req: any) {
    return this.zuDocService.deleteDocument(req.tenantId, id);
  }

  // ─── Shared Links ────────────────────────────────────────────
  @Post('documents/:id/share')
  @UseGuards(JwtAuthGuard)
  @ApiOperation({ summary: 'Create shared link for document' })
  createSharedLink(@Param('id') id: string, @Body() body: any, @Request() req: any) {
    return this.zuDocService.createSharedLink(req.tenantId, id, body);
  }

  @Get('shared/:token')
  @Public()
  @ApiOperation({ summary: 'Access document via shared link (public)' })
  getSharedDocument(@Param('token') token: string) {
    return this.zuDocService.getDocumentBySharedToken(token);
  }

  // ─── Signatures ──────────────────────────────────────────────
  @Get('signatures')
  @UseGuards(JwtAuthGuard)
  @ApiOperation({ summary: 'Get signature requests' })
  getSignatureRequests(@Request() req: any) {
    return this.zuDocService.getSignatureRequests(req.tenantId);
  }

  @Post('signatures')
  @UseGuards(JwtAuthGuard)
  @ApiOperation({ summary: 'Create signature request' })
  createSignatureRequest(@Body() body: any, @Request() req: any) {
    return this.zuDocService.createSignatureRequest(req.tenantId, req.user.id, body);
  }

  @Post('sign/:token')
  @Public()
  @ApiOperation({ summary: 'Sign a document (public)' })
  signDocument(
    @Param('token') token: string,
    @Body() body: { signatureData: string },
    @Ip() ip: string,
  ) {
    return this.zuDocService.signDocument(token, body.signatureData, ip);
  }
}
