import {
  Entity, PrimaryGeneratedColumn, Column, CreateDateColumn,
  UpdateDateColumn, ManyToOne, JoinColumn, OneToMany, Index,
} from 'typeorm';
import { User } from '../../users/entities/user.entity';

@Entity('document_folders')
@Index(['tenantId'])
export class DocumentFolder {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  tenantId: string;

  @Column()
  name: string;

  @Column({ nullable: true })
  parentId: string;

  @ManyToOne(() => DocumentFolder, { nullable: true })
  @JoinColumn({ name: 'parentId' })
  parent: DocumentFolder;

  @Column()
  createdById: string;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}

@Entity('documents')
@Index(['tenantId'])
export class Document {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  tenantId: string;

  @Column()
  title: string;

  @Column({ type: 'text', default: '' })
  content: string;

  @Column({ nullable: true })
  folderId: string;

  @ManyToOne(() => DocumentFolder, { nullable: true })
  @JoinColumn({ name: 'folderId' })
  folder: DocumentFolder;

  @Column({ default: 'draft' })
  status: string; // draft | active | archived

  @Column({ type: 'text', array: true, default: '{}' })
  tags: string[];

  @Column({ default: 1 })
  currentVersion: number;

  @Column()
  createdById: string;

  @ManyToOne(() => User)
  @JoinColumn({ name: 'createdById' })
  createdBy: User;

  @OneToMany(() => DocumentVersion, (v) => v.document, { cascade: true })
  versions: DocumentVersion[];

  @OneToMany(() => SharedLink, (l) => l.document, { cascade: true })
  sharedLinks: SharedLink[];

  @OneToMany(() => SignatureRequest, (s) => s.document, { cascade: true })
  signatureRequests: SignatureRequest[];

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}

@Entity('document_versions')
@Index(['documentId'])
export class DocumentVersion {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  documentId: string;

  @ManyToOne(() => Document, (d) => d.versions, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'documentId' })
  document: Document;

  @Column()
  version: number;

  @Column({ type: 'text' })
  content: string;

  @Column()
  changedById: string;

  @ManyToOne(() => User)
  @JoinColumn({ name: 'changedById' })
  changedBy: User;

  @Column({ nullable: true })
  changeSummary: string;

  @CreateDateColumn()
  createdAt: Date;
}

@Entity('shared_links')
export class SharedLink {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  documentId: string;

  @ManyToOne(() => Document, (d) => d.sharedLinks, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'documentId' })
  document: Document;

  @Column({ unique: true })
  token: string;

  @Column({ default: 'view' })
  permissions: string; // view | comment | edit

  @Column({ nullable: true })
  expiresAt: Date;

  @Column({ default: true })
  isActive: boolean;

  @CreateDateColumn()
  createdAt: Date;
}

@Entity('signature_requests')
@Index(['tenantId'])
export class SignatureRequest {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  tenantId: string;

  @Column()
  documentId: string;

  @ManyToOne(() => Document, (d) => d.signatureRequests)
  @JoinColumn({ name: 'documentId' })
  document: Document;

  @Column()
  title: string;

  @Column({ type: 'text', nullable: true })
  message: string;

  @Column({ default: 'pending' })
  status: string; // pending | in_progress | completed | cancelled | expired

  @Column({ nullable: true })
  completedAt: Date;

  @Column({ nullable: true })
  expiresAt: Date;

  @Column()
  createdById: string;

  @ManyToOne(() => User)
  @JoinColumn({ name: 'createdById' })
  createdBy: User;

  @OneToMany(() => Signatory, (s) => s.signatureRequest, { cascade: true })
  signatories: Signatory[];

  @OneToMany(() => SignatureAuditEntry, (a) => a.signatureRequest, { cascade: true })
  auditLog: SignatureAuditEntry[];

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}

@Entity('signatories')
export class Signatory {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  signatureRequestId: string;

  @ManyToOne(() => SignatureRequest, (s) => s.signatories, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'signatureRequestId' })
  signatureRequest: SignatureRequest;

  @Column()
  email: string;

  @Column()
  name: string;

  @Column({ default: 1 })
  order: number;

  @Column({ default: 'pending' })
  status: string; // pending | viewed | signed | declined

  @Column({ nullable: true })
  signedAt: Date;

  @Column({ nullable: true })
  declinedAt: Date;

  @Column({ nullable: true })
  signatureImageUrl: string;

  @Column({ nullable: true })
  ipAddress: string;

  @Column({ nullable: true })
  signingToken: string;

  @CreateDateColumn()
  createdAt: Date;
}

@Entity('signature_audit_log')
export class SignatureAuditEntry {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  signatureRequestId: string;

  @ManyToOne(() => SignatureRequest, (s) => s.auditLog, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'signatureRequestId' })
  signatureRequest: SignatureRequest;

  @Column()
  event: string; // created | viewed | signed | declined | completed | expired

  @Column({ nullable: true })
  actorEmail: string;

  @Column({ nullable: true })
  ipAddress: string;

  @Column({ type: 'jsonb', nullable: true })
  metadata: Record<string, any>;

  @CreateDateColumn()
  createdAt: Date;
}
