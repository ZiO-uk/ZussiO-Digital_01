import {
  Controller, Get, Post, Put, Delete, Param, Body, Query,
  UseGuards, Request, HttpCode, HttpStatus,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { ZuCardsService } from './zucards.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { Public } from '../../common/decorators/public.decorator';

@ApiTags('zucards')
@ApiBearerAuth()
@Controller({ path: 'zucards', version: '1' })
export class ZuCardsController {
  constructor(private readonly zuCardsService: ZuCardsService) {}

  @Get('templates')
  @Public()
  @ApiOperation({ summary: 'Get card templates' })
  getTemplates(@Query('category') category?: string) {
    return this.zuCardsService.getTemplates(category);
  }

  @Get('cards')
  @UseGuards(JwtAuthGuard)
  @ApiOperation({ summary: 'Get cards for current tenant' })
  getCards(@Request() req: any) {
    return this.zuCardsService.getCards(req.tenantId);
  }

  @Get('cards/:id')
  @UseGuards(JwtAuthGuard)
  @ApiOperation({ summary: 'Get card by ID' })
  getCard(@Param('id') id: string, @Request() req: any) {
    return this.zuCardsService.getCard(req.tenantId, id);
  }

  @Post('cards')
  @UseGuards(JwtAuthGuard)
  @ApiOperation({ summary: 'Create a group card' })
  createCard(@Body() body: any, @Request() req: any) {
    return this.zuCardsService.createCard(req.tenantId, req.user.id, body);
  }

  @Put('cards/:id')
  @UseGuards(JwtAuthGuard)
  @ApiOperation({ summary: 'Update card' })
  updateCard(@Param('id') id: string, @Body() body: any, @Request() req: any) {
    return this.zuCardsService.updateCard(req.tenantId, id, body);
  }

  @Post('cards/:id/deliver')
  @UseGuards(JwtAuthGuard)
  @ApiOperation({ summary: 'Deliver card to recipient' })
  deliverCard(@Param('id') id: string, @Request() req: any) {
    return this.zuCardsService.deliverCard(req.tenantId, id);
  }

  @Delete('cards/:id')
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Delete card' })
  deleteCard(@Param('id') id: string, @Request() req: any) {
    return this.zuCardsService.deleteCard(req.tenantId, id);
  }

  /** Public endpoint – anyone with the token can add a contribution */
  @Post('contribute/:token')
  @Public()
  @ApiOperation({ summary: 'Add contribution to a card (public)' })
  addContribution(@Param('token') token: string, @Body() body: any) {
    return this.zuCardsService.addContribution(token, body);
  }

  /** Public endpoint – view a card by token */
  @Get('view/:token')
  @Public()
  @ApiOperation({ summary: 'View card by shareable token (public)' })
  viewCard(@Param('token') token: string) {
    return this.zuCardsService.getCardByToken(token);
  }
}
