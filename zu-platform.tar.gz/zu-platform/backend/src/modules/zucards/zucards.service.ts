import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CardTemplate, GroupCard, CardContribution } from './entities/zucards.entities';
import { NotificationsService } from '../notifications/notifications.service';
import { ConfigService } from '@nestjs/config';
import { v4 as uuid } from 'uuid';

@Injectable()
export class ZuCardsService {
  constructor(
    @InjectRepository(CardTemplate)    private templateRepo: Repository<CardTemplate>,
    @InjectRepository(GroupCard)       private cardRepo: Repository<GroupCard>,
    @InjectRepository(CardContribution) private contributionRepo: Repository<CardContribution>,
    private readonly notifService: NotificationsService,
    private readonly configService: ConfigService,
  ) {}

  async getTemplates(category?: string) {
    const where: any = { isActive: true };
    if (category) where.category = category;
    return this.templateRepo.find({ where, order: { name: 'ASC' } });
  }

  async getCards(tenantId: string) {
    return this.cardRepo.find({
      where: { tenantId },
      relations: ['contributions', 'template'],
      order: { createdAt: 'DESC' },
    });
  }

  async getCard(tenantId: string, id: string): Promise<GroupCard> {
    const card = await this.cardRepo.findOne({
      where: { id, tenantId },
      relations: ['contributions', 'template'],
    });
    if (!card) throw new NotFoundException('Card not found');
    return card;
  }

  async getCardByToken(token: string): Promise<GroupCard> {
    const card = await this.cardRepo.findOne({
      where: { shareableToken: token },
      relations: ['contributions', 'template'],
    });
    if (!card) throw new NotFoundException('Card not found');
    return card;
  }

  async createCard(tenantId: string, createdById: string, data: any): Promise<GroupCard> {
    const token = uuid().replace(/-/g, '').substring(0, 24);
    const frontendUrl = this.configService.get<string>('FRONTEND_URL', 'http://localhost:3000');

    const card = this.cardRepo.create({
      ...data,
      tenantId,
      createdById,
      shareableToken: token,
      shareableLink: `${frontendUrl}/cards/${token}`,
      status: 'collecting',
    });

    return this.cardRepo.save(card);
  }

  async updateCard(tenantId: string, id: string, data: any): Promise<GroupCard> {
    const card = await this.getCard(tenantId, id);
    Object.assign(card, data);
    return this.cardRepo.save(card);
  }

  async addContribution(token: string, data: Partial<CardContribution>): Promise<CardContribution> {
    const card = await this.getCardByToken(token);
    const contribution = this.contributionRepo.create({ ...data, cardId: card.id });
    return this.contributionRepo.save(contribution);
  }

  async deliverCard(tenantId: string, id: string): Promise<GroupCard> {
    const card = await this.getCard(tenantId, id);
    card.status = 'delivered';
    card.deliveredAt = new Date();

    // Send email
    await this.notifService.sendCardDeliveryEmail(
      card.recipientEmail,
      card.recipientName,
      card.shareableLink,
      'Your team',
    );

    return this.cardRepo.save(card);
  }

  async deleteCard(tenantId: string, id: string): Promise<void> {
    const card = await this.getCard(tenantId, id);
    await this.cardRepo.remove(card);
  }
}
