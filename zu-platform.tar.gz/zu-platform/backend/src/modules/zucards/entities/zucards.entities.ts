import {
  Entity, PrimaryGeneratedColumn, Column, CreateDateColumn,
  UpdateDateColumn, ManyToOne, JoinColumn, OneToMany, Index,
} from 'typeorm';
import { User } from '../../users/entities/user.entity';

@Entity('card_templates')
export class CardTemplate {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  name: string;

  @Column()
  category: string; // birthday | work_anniversary | farewell | congratulations | holiday | custom

  @Column({ nullable: true })
  thumbnailUrl: string;

  @Column({ type: 'jsonb', default: '{}' })
  designData: Record<string, any>;

  @Column({ default: false })
  isPremium: boolean;

  @Column({ default: true })
  isActive: boolean;

  @CreateDateColumn()
  createdAt: Date;
}

@Entity('group_cards')
@Index(['tenantId'])
export class GroupCard {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  tenantId: string;

  @Column()
  title: string;

  @Column()
  recipientName: string;

  @Column()
  recipientEmail: string;

  @Column({ nullable: true })
  templateId: string;

  @ManyToOne(() => CardTemplate, { nullable: true })
  @JoinColumn({ name: 'templateId' })
  template: CardTemplate;

  @Column()
  category: string;

  @Column({ type: 'jsonb', default: '{}' })
  designData: Record<string, any>;

  @Column({ nullable: true })
  scheduledDeliveryAt: Date;

  @Column({ nullable: true })
  deliveredAt: Date;

  @Column({ unique: true })
  shareableLink: string;

  @Column({ nullable: true })
  shareableToken: string;

  @Column({ default: 'draft' })
  status: string; // draft | collecting | scheduled | delivered

  @Column()
  createdById: string;

  @ManyToOne(() => User)
  @JoinColumn({ name: 'createdById' })
  createdBy: User;

  @OneToMany(() => CardContribution, (c) => c.card, { cascade: true })
  contributions: CardContribution[];

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}

@Entity('card_contributions')
export class CardContribution {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  cardId: string;

  @ManyToOne(() => GroupCard, (c) => c.contributions, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'cardId' })
  card: GroupCard;

  @Column()
  contributorName: string;

  @Column({ nullable: true })
  contributorEmail: string;

  @Column({ type: 'text' })
  message: string;

  @Column({ nullable: true })
  gifUrl: string;

  @Column({ nullable: true })
  stickerUrl: string;

  @Column({ type: 'jsonb', default: '{"x": 0, "y": 0}' })
  position: { x: number; y: number };

  @CreateDateColumn()
  createdAt: Date;
}
