import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CardTemplate, GroupCard, CardContribution } from './entities/zucards.entities';
import { ZuCardsService } from './zucards.service';
import { ZuCardsController } from './zucards.controller';
import { NotificationsModule } from '../notifications/notifications.module';
import { BillingModule } from '../billing/billing.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([CardTemplate, GroupCard, CardContribution]),
    NotificationsModule,
    BillingModule,
  ],
  providers: [ZuCardsService],
  controllers: [ZuCardsController],
  exports: [ZuCardsService],
})
export class ZuCardsModule {}
