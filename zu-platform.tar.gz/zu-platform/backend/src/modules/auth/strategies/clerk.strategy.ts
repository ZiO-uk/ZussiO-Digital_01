import { Injectable, UnauthorizedException } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { Strategy } from 'passport-custom';
import { ConfigService } from '@nestjs/config';
import { AuthService } from '../auth.service';

/**
 * ClerkStrategy
 * ─────────────────────────────────────────────────────────────
 * Validates Clerk session tokens forwarded from the Next.js
 * frontend. The frontend sends the Clerk session token in the
 * Authorization header which this strategy verifies against
 * Clerk's public API.
 *
 * In production replace the stub with actual Clerk JWT verification
 * using Clerk's `@clerk/backend` SDK.
 */
@Injectable()
export class ClerkStrategy extends PassportStrategy(Strategy, 'clerk') {
  constructor(
    private readonly configService: ConfigService,
    private readonly authService: AuthService,
  ) {
    super();
  }

  async validate(req: any): Promise<any> {
    const authHeader = req.headers['authorization'];

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new UnauthorizedException('No bearer token provided');
    }

    const token = authHeader.split(' ')[1];

    // TODO: replace stub with Clerk SDK verification
    // const { verifyToken } = require('@clerk/backend');
    // const payload = await verifyToken(token, { secretKey: this.configService.get('CLERK_SECRET_KEY') });

    // For now, fall through to JWT strategy
    throw new UnauthorizedException('Use JWT strategy for API requests');
  }
}
