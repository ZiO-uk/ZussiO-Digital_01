import { Injectable, UnauthorizedException, ConflictException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User } from '../users/entities/user.entity';
import { Tenant } from '../tenants/entities/tenant.entity';
import { TenantsService } from '../tenants/tenants.service';

export interface ClerkWebhookPayload {
  type: string;
  data: {
    id: string;
    email_addresses: Array<{ email_address: string }>;
    first_name: string;
    last_name: string;
    image_url: string;
    unsafe_metadata?: { tenantId?: string; role?: string };
    public_metadata?: { tenantId?: string; role?: string };
  };
}

@Injectable()
export class AuthService {
  constructor(
    @InjectRepository(User)
    private readonly userRepo: Repository<User>,
    @InjectRepository(Tenant)
    private readonly tenantRepo: Repository<Tenant>,
    private readonly jwtService: JwtService,
    private readonly tenantsService: TenantsService,
  ) {}

  /**
   * Syncs a Clerk user.created webhook into the platform database.
   * Creates a tenant if the user is registering a new organisation.
   */
  async syncClerkUserCreated(payload: ClerkWebhookPayload): Promise<User> {
    const { data } = payload;
    const email = data.email_addresses[0]?.email_address;

    if (!email) throw new UnauthorizedException('No email on Clerk user');

    // Check existing
    const existing = await this.userRepo.findOne({ where: { clerkId: data.id } });
    if (existing) return existing;

    // Create or find tenant
    const metaTenantId = data.public_metadata?.tenantId;
    let tenant: Tenant;

    if (metaTenantId) {
      tenant = await this.tenantsService.findById(metaTenantId);
    } else {
      // New registration – create a tenant
      const companyName = `${data.first_name}'s Organisation`;
      tenant = await this.tenantsService.create({
        name: companyName,
        billingEmail: email,
        plan: 'free',
      });
    }

    const user = this.userRepo.create({
      clerkId: data.id,
      email,
      firstName: data.first_name || '',
      lastName: data.last_name || '',
      avatarUrl: data.image_url,
      tenantId: tenant.id,
      role: data.public_metadata?.role as any || 'tenant_admin',
    });

    const savedUser = await this.userRepo.save(user);
    await this.tenantsService.incrementUserCount(tenant.id);

    return savedUser;
  }

  async syncClerkUserUpdated(payload: ClerkWebhookPayload): Promise<User | null> {
    const { data } = payload;
    const user = await this.userRepo.findOne({ where: { clerkId: data.id } });
    if (!user) return null;

    const email = data.email_addresses[0]?.email_address;
    if (email) user.email = email;
    if (data.first_name) user.firstName = data.first_name;
    if (data.last_name) user.lastName = data.last_name;
    if (data.image_url) user.avatarUrl = data.image_url;

    return this.userRepo.save(user);
  }

  async syncClerkUserDeleted(clerkId: string): Promise<void> {
    const user = await this.userRepo.findOne({ where: { clerkId } });
    if (!user) return;
    await this.tenantsService.decrementUserCount(user.tenantId);
    await this.userRepo.remove(user);
  }

  async validateUserByClerkId(clerkId: string): Promise<User | null> {
    return this.userRepo.findOne({
      where: { clerkId, isActive: true },
    });
  }

  async findUserByClerkId(clerkId: string): Promise<User | null> {
    return this.userRepo.findOne({ where: { clerkId } });
  }

  generateJwt(user: User): string {
    return this.jwtService.sign({
      sub: user.id,
      clerkId: user.clerkId,
      email: user.email,
      role: user.role,
      tenantId: user.tenantId,
    });
  }
}
