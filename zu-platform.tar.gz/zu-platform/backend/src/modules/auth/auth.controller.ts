import {
  Controller, Post, Body, Headers, HttpCode, HttpStatus, BadRequestException,
} from '@nestjs/common';
import { ApiTags, ApiOperation } from '@nestjs/swagger';
import { ConfigService } from '@nestjs/config';
import { Webhook } from 'svix';
import { AuthService, ClerkWebhookPayload } from './auth.service';
import { Public } from '../../common/decorators/public.decorator';

@ApiTags('auth')
@Controller({ path: 'auth', version: '1' })
export class AuthController {
  constructor(
    private readonly authService: AuthService,
    private readonly configService: ConfigService,
  ) {}

  /**
   * Clerk webhook – syncs user lifecycle events into the platform DB.
   * Verify with svix: https://docs.svix.com/receiving/verifying-payloads
   */
  @Post('webhook/clerk')
  @Public()
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Clerk webhook receiver' })
  async handleClerkWebhook(
    @Body() rawBody: Buffer,
    @Headers('svix-id') svixId: string,
    @Headers('svix-timestamp') svixTimestamp: string,
    @Headers('svix-signature') svixSignature: string,
  ) {
    const secret = this.configService.get<string>('CLERK_WEBHOOK_SECRET');

    if (!secret) {
      throw new BadRequestException('Webhook secret not configured');
    }

    const wh = new Webhook(secret);

    let event: ClerkWebhookPayload;
    try {
      event = wh.verify(rawBody.toString(), {
        'svix-id':        svixId,
        'svix-timestamp': svixTimestamp,
        'svix-signature': svixSignature,
      }) as ClerkWebhookPayload;
    } catch {
      throw new BadRequestException('Invalid webhook signature');
    }

    switch (event.type) {
      case 'user.created':
        await this.authService.syncClerkUserCreated(event);
        break;
      case 'user.updated':
        await this.authService.syncClerkUserUpdated(event);
        break;
      case 'user.deleted':
        await this.authService.syncClerkUserDeleted(event.data.id);
        break;
      default:
        // Ignore unhandled event types
        break;
    }

    return { received: true };
  }

  @Post('health')
  @Public()
  @ApiOperation({ summary: 'Auth service health' })
  health() {
    return { status: 'ok', service: 'auth' };
  }
}
