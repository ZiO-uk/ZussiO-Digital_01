import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ThrottlerModule } from '@nestjs/throttler';
import { TerminusModule } from '@nestjs/terminus';
import { AuthModule } from './modules/auth/auth.module';
import { UsersModule } from './modules/users/users.module';
import { TenantsModule } from './modules/tenants/tenants.module';
import { BillingModule } from './modules/billing/billing.module';
import { NotificationsModule } from './modules/notifications/notifications.module';
import { IsmsModule } from './modules/isms/isms.module';
import { ZuCardsModule } from './modules/zucards/zucards.module';
import { ZuDocModule } from './modules/zudoc/zudoc.module';
import { HealthController } from './health.controller';
import databaseConfig from './config/database.config';
import appConfig from './config/app.config';

@Module({
  imports: [
    // ─── Configuration ──────────────────────────────────────
    ConfigModule.forRoot({
      isGlobal: true,
      load: [appConfig, databaseConfig],
      envFilePath: ['.env.local', '.env'],
    }),

    // ─── Database ───────────────────────────────────────────
    TypeOrmModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        type: 'postgres',
        url: config.get<string>('DATABASE_URL'),
        autoLoadEntities: true,
        synchronize: config.get<string>('NODE_ENV') === 'development',
        logging: config.get<string>('NODE_ENV') === 'development',
        ssl: config.get<string>('NODE_ENV') === 'production'
          ? { rejectUnauthorized: false }
          : false,
      }),
    }),

    // ─── Rate Limiting ──────────────────────────────────────
    ThrottlerModule.forRoot([
      { name: 'short', ttl: 1000,  limit: 20 },
      { name: 'medium', ttl: 10000, limit: 100 },
      { name: 'long',  ttl: 60000, limit: 500 },
    ]),

    // ─── Health Checks ──────────────────────────────────────
    TerminusModule,

    // ─── Feature Modules ────────────────────────────────────
    AuthModule,
    UsersModule,
    TenantsModule,
    BillingModule,
    NotificationsModule,
    IsmsModule,
    ZuCardsModule,
    ZuDocModule,
  ],
  controllers: [HealthController],
})
export class AppModule {}
