import { NestFactory } from '@nestjs/core';
import { ValidationPipe, VersioningType } from '@nestjs/common';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import { ConfigService } from '@nestjs/config';
import helmet from 'helmet';
import compression from 'compression';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule, {
    logger: ['error', 'warn', 'log', 'debug'],
  });

  const config = app.get(ConfigService);

  // ─── Security ──────────────────────────────────────────────
  app.use(helmet());
  app.use(compression());

  // CORS
  app.enableCors({
    origin: config.get<string>('FRONTEND_URL') || 'http://localhost:3000',
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  });

  // ─── Global Pipes ──────────────────────────────────────────
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
      transformOptions: { enableImplicitConversion: true },
    }),
  );

  // ─── API Versioning ────────────────────────────────────────
  app.enableVersioning({ type: VersioningType.URI });
  app.setGlobalPrefix('api');

  // ─── Swagger / OpenAPI ─────────────────────────────────────
  const swaggerConfig = new DocumentBuilder()
    .setTitle('Zu Platform API')
    .setDescription('Enterprise SaaS Platform REST API')
    .setVersion('1.0')
    .addBearerAuth()
    .addTag('auth',          'Authentication & registration')
    .addTag('users',         'User management')
    .addTag('tenants',       'Tenant management')
    .addTag('billing',       'Subscriptions & invoicing')
    .addTag('isms',          'ISMS Trustee – compliance management')
    .addTag('zucards',       'ZuCards – group eCards')
    .addTag('zudoc',         'ZuDoc – document management & e-signatures')
    .addTag('notifications', 'Notification centre')
    .addTag('health',        'Health checks')
    .build();

  const document = SwaggerModule.createDocument(app, swaggerConfig);
  SwaggerModule.setup('api/docs', app, document, {
    swaggerOptions: { persistAuthorization: true },
  });

  const port = config.get<number>('PORT') || 4000;
  await app.listen(port);
  console.log(`🚀 Zu Platform API running on http://localhost:${port}`);
  console.log(`📖 API Docs available at http://localhost:${port}/api/docs`);
}

bootstrap();
