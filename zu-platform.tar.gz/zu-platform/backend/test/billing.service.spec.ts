import { Test, TestingModule } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { BillingService } from '../../src/modules/billing/billing.service';
import {
  SubscriptionPlan, TenantSubscription, ApplicationEntitlement,
  FeatureFlag, Invoice, UsageRecord,
} from '../../src/modules/billing/entities/billing.entities';
import { TenantsService } from '../../src/modules/tenants/tenants.service';

const mockRepo = () => ({
  find: jest.fn(),
  findOne: jest.fn(),
  create: jest.fn(),
  save: jest.fn(),
  update: jest.fn(),
  count: jest.fn(),
});

const mockTenantsService = {
  findById: jest.fn(),
  update: jest.fn(),
};

describe('BillingService', () => {
  let service: BillingService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        BillingService,
        { provide: getRepositoryToken(SubscriptionPlan),      useFactory: mockRepo },
        { provide: getRepositoryToken(TenantSubscription),    useFactory: mockRepo },
        { provide: getRepositoryToken(ApplicationEntitlement), useFactory: mockRepo },
        { provide: getRepositoryToken(FeatureFlag),            useFactory: mockRepo },
        { provide: getRepositoryToken(Invoice),                useFactory: mockRepo },
        { provide: getRepositoryToken(UsageRecord),            useFactory: mockRepo },
        { provide: TenantsService, useValue: mockTenantsService },
      ],
    }).compile();

    service = module.get<BillingService>(BillingService);
  });

  afterEach(() => jest.clearAllMocks());

  describe('getPublicPlans', () => {
    it('returns active public plans ordered by sortOrder', async () => {
      const plans = [
        { slug: 'free', name: 'Free', sortOrder: 1 },
        { slug: 'gold', name: 'Gold', sortOrder: 3 },
      ];
      const planRepo = service['planRepo'];
      (planRepo.find as jest.Mock).mockResolvedValue(plans);

      const result = await service.getPublicPlans();
      expect(result).toEqual(plans);
      expect(planRepo.find).toHaveBeenCalledWith({
        where: { isPublic: true, isActive: true },
        order: { sortOrder: 'ASC' },
      });
    });
  });

  describe('checkAppEntitlement', () => {
    it('returns true when entitlement exists and is enabled', async () => {
      const entitlementRepo = service['entitlementRepo'];
      (entitlementRepo.findOne as jest.Mock).mockResolvedValue({ enabled: true });

      const result = await service.checkAppEntitlement('gold', 'isms');
      expect(result).toBe(true);
    });

    it('returns false when no entitlement found', async () => {
      const entitlementRepo = service['entitlementRepo'];
      (entitlementRepo.findOne as jest.Mock).mockResolvedValue(null);

      const result = await service.checkAppEntitlement('free', 'isms');
      expect(result).toBe(false);
    });
  });

  describe('checkFeatureFlag', () => {
    it('returns true when feature flag is enabled', async () => {
      const flagRepo = service['featureFlagRepo'];
      (flagRepo.findOne as jest.Mock).mockResolvedValue({ enabled: true });

      const result = await service.checkFeatureFlag('gold', 'isms.risk_register');
      expect(result).toBe(true);
    });

    it('returns false when feature flag is disabled', async () => {
      const flagRepo = service['featureFlagRepo'];
      (flagRepo.findOne as jest.Mock).mockResolvedValue(null);

      const result = await service.checkFeatureFlag('free', 'isms.compliance_reporting');
      expect(result).toBe(false);
    });
  });

  describe('createOrUpdateSubscription', () => {
    it('creates a new subscription when none exists', async () => {
      const subRepo = service['subscriptionRepo'];
      (subRepo.findOne as jest.Mock).mockResolvedValue(null);
      (subRepo.create as jest.Mock).mockImplementation((data) => data);
      (subRepo.save as jest.Mock).mockImplementation((data) => ({ ...data, id: 'sub-123' }));
      (mockTenantsService.update as jest.Mock).mockResolvedValue({});

      const result = await service.createOrUpdateSubscription('tenant-1', 'gold');
      expect(subRepo.save).toHaveBeenCalled();
      expect(mockTenantsService.update).toHaveBeenCalledWith('tenant-1', {
        plan: 'gold',
        subscriptionStatus: 'active',
      });
    });

    it('updates an existing subscription', async () => {
      const existingSub = { id: 'sub-1', tenantId: 'tenant-1', planSlug: 'free' };
      const subRepo = service['subscriptionRepo'];
      (subRepo.findOne as jest.Mock).mockResolvedValue(existingSub);
      (subRepo.save as jest.Mock).mockResolvedValue({ ...existingSub, planSlug: 'gold' });
      (mockTenantsService.update as jest.Mock).mockResolvedValue({});

      await service.createOrUpdateSubscription('tenant-1', 'gold');
      expect(existingSub['planSlug']).toBe('gold');
      expect(subRepo.save).toHaveBeenCalled();
    });
  });

  describe('createInvoice', () => {
    it('generates a sequential invoice number', async () => {
      const invoiceRepo = service['invoiceRepo'];
      (invoiceRepo.count as jest.Mock).mockResolvedValue(2);
      (invoiceRepo.create as jest.Mock).mockImplementation((d) => d);
      (invoiceRepo.save as jest.Mock).mockImplementation((d) => d);

      const invoice = await service.createInvoice({
        tenantId: 'tenant-1',
        totalGbp: 99,
      });

      expect(invoice.number).toMatch(/^INV-\d{4}-0003$/);
    });
  });

  describe('recordUsage', () => {
    it('saves a usage record with current timestamp', async () => {
      const usageRepo = service['usageRepo'];
      (usageRepo.create as jest.Mock).mockImplementation((d) => d);
      (usageRepo.save as jest.Mock).mockResolvedValue({});

      await service.recordUsage('tenant-1', 'documents', 23);
      expect(usageRepo.save).toHaveBeenCalledWith(
        expect.objectContaining({
          tenantId: 'tenant-1',
          metricKey: 'documents',
          value: 23,
        }),
      );
    });
  });
});
