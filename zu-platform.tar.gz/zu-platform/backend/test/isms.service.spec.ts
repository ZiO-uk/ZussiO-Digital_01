import { Test, TestingModule } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { NotFoundException } from '@nestjs/common';
import { IsmsService } from '../../src/modules/isms/isms.service';
import {
  IsmsRisk, IsmsControl, IsmsPolicy,
  PolicyAcknowledgement, IsmsAudit, AuditFinding,
} from '../../src/modules/isms/entities/isms.entities';

const mockRepo = () => ({
  find: jest.fn(),
  findOne: jest.fn(),
  create: jest.fn(),
  save: jest.fn(),
  remove: jest.fn(),
  update: jest.fn(),
  count: jest.fn(),
});

const TENANT_ID = 'tenant-abc-123';

describe('IsmsService', () => {
  let service: IsmsService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        IsmsService,
        { provide: getRepositoryToken(IsmsRisk),              useFactory: mockRepo },
        { provide: getRepositoryToken(IsmsControl),           useFactory: mockRepo },
        { provide: getRepositoryToken(IsmsPolicy),            useFactory: mockRepo },
        { provide: getRepositoryToken(PolicyAcknowledgement), useFactory: mockRepo },
        { provide: getRepositoryToken(IsmsAudit),             useFactory: mockRepo },
        { provide: getRepositoryToken(AuditFinding),          useFactory: mockRepo },
      ],
    }).compile();

    service = module.get<IsmsService>(IsmsService);
  });

  afterEach(() => jest.clearAllMocks());

  // ─── Risks ──────────────────────────────────────────────────
  describe('getRisks', () => {
    it('returns all risks for a tenant', async () => {
      const risks = [
        { id: 'r1', tenantId: TENANT_ID, title: 'Phishing', likelihood: 4, impact: 5 },
        { id: 'r2', tenantId: TENANT_ID, title: 'Ransomware', likelihood: 3, impact: 5 },
      ];
      const riskRepo = service['riskRepo'];
      (riskRepo.find as jest.Mock).mockResolvedValue(risks);

      const result = await service.getRisks(TENANT_ID);
      expect(result).toHaveLength(2);
      expect(riskRepo.find).toHaveBeenCalledWith({
        where: { tenantId: TENANT_ID },
        order: { createdAt: 'DESC' },
      });
    });

    it('filters by status when provided', async () => {
      const riskRepo = service['riskRepo'];
      (riskRepo.find as jest.Mock).mockResolvedValue([]);

      await service.getRisks(TENANT_ID, { status: 'open' });
      expect(riskRepo.find).toHaveBeenCalledWith({
        where: { tenantId: TENANT_ID, status: 'open' },
        order: { createdAt: 'DESC' },
      });
    });
  });

  describe('getRisk', () => {
    it('returns a single risk by id', async () => {
      const risk = { id: 'r1', tenantId: TENANT_ID, title: 'Test Risk' };
      const riskRepo = service['riskRepo'];
      (riskRepo.findOne as jest.Mock).mockResolvedValue(risk);

      const result = await service.getRisk(TENANT_ID, 'r1');
      expect(result).toEqual(risk);
    });

    it('throws NotFoundException when risk not found', async () => {
      const riskRepo = service['riskRepo'];
      (riskRepo.findOne as jest.Mock).mockResolvedValue(null);

      await expect(service.getRisk(TENANT_ID, 'nonexistent')).rejects.toThrow(NotFoundException);
    });
  });

  describe('createRisk', () => {
    it('creates a risk with tenantId', async () => {
      const data = { title: 'New Risk', likelihood: 3, impact: 4 };
      const created = { ...data, tenantId: TENANT_ID, id: 'r-new' };
      const riskRepo = service['riskRepo'];
      (riskRepo.create as jest.Mock).mockReturnValue(created);
      (riskRepo.save as jest.Mock).mockResolvedValue(created);

      const result = await service.createRisk(TENANT_ID, data);
      expect(result.tenantId).toBe(TENANT_ID);
      expect(riskRepo.create).toHaveBeenCalledWith({ ...data, tenantId: TENANT_ID });
    });
  });

  describe('getRiskMatrix', () => {
    it('categorises risks by severity correctly', async () => {
      const risks = [
        { id: 'r1', severity: 'critical', likelihood: 5, impact: 5 },
        { id: 'r2', severity: 'high',     likelihood: 4, impact: 4 },
        { id: 'r3', severity: 'medium',   likelihood: 3, impact: 3 },
        { id: 'r4', severity: 'low',      likelihood: 2, impact: 2 },
        { id: 'r5', severity: 'critical', likelihood: 4, impact: 5 },
      ];
      const riskRepo = service['riskRepo'];
      (riskRepo.find as jest.Mock).mockResolvedValue(risks);

      const result = await service.getRiskMatrix(TENANT_ID);

      expect(result.totals.critical).toBe(2);
      expect(result.totals.high).toBe(1);
      expect(result.totals.medium).toBe(1);
      expect(result.totals.low).toBe(1);
      expect(result.totals.total).toBe(5);
    });
  });

  // ─── Controls ────────────────────────────────────────────────
  describe('getComplianceSummary', () => {
    it('calculates compliance percentage correctly', async () => {
      const controls = [
        { status: 'implemented' },
        { status: 'implemented' },
        { status: 'in_progress' },
        { status: 'not_started' },
        { status: 'not_applicable' },
      ];
      const controlRepo = service['controlRepo'];
      (controlRepo.find as jest.Mock).mockResolvedValue(controls);

      const result = await service.getComplianceSummary(TENANT_ID, 'iso27001');

      expect(result.framework).toBe('iso27001');
      expect(result.total).toBe(5);
      expect(result.implemented).toBe(2);
      expect(result.notApplicable).toBe(1);
      // (2 implemented + 1 not_applicable) / 5 = 60%
      expect(result.compliancePercent).toBe(60);
    });

    it('returns 0% when no controls exist', async () => {
      const controlRepo = service['controlRepo'];
      (controlRepo.find as jest.Mock).mockResolvedValue([]);

      const result = await service.getComplianceSummary(TENANT_ID, 'iso27001');
      expect(result.compliancePercent).toBe(0);
    });
  });

  // ─── Policies ────────────────────────────────────────────────
  describe('acknowledgePolicy', () => {
    it('creates a new acknowledgement when one does not exist', async () => {
      const ackRepo = service['ackRepo'];
      (ackRepo.findOne as jest.Mock).mockResolvedValue(null);
      (ackRepo.create as jest.Mock).mockImplementation((d) => d);
      (ackRepo.save as jest.Mock).mockResolvedValue({ id: 'ack-1', policyId: 'p1', userId: 'u1' });

      const result = await service.acknowledgePolicy('p1', 'u1');
      expect(ackRepo.save).toHaveBeenCalled();
    });

    it('returns existing acknowledgement without duplicate', async () => {
      const existingAck = { id: 'ack-1', policyId: 'p1', userId: 'u1' };
      const ackRepo = service['ackRepo'];
      (ackRepo.findOne as jest.Mock).mockResolvedValue(existingAck);

      const result = await service.acknowledgePolicy('p1', 'u1');
      expect(result).toEqual(existingAck);
      expect(ackRepo.save).not.toHaveBeenCalled();
    });
  });
});
