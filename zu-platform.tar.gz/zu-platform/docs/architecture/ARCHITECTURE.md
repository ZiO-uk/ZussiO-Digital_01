# Zu Platform – Architecture Overview

## System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      Zu Platform                             │
├──────────────────────┬──────────────────────────────────────┤
│   Frontend (Next.js) │       Backend (NestJS)               │
│   Vercel CDN         │       Railway                        │
│                      │                                      │
│  ┌─────────────┐     │   ┌──────────────────────────────┐   │
│  │ Marketing   │     │   │  Auth Module (Clerk + JWT)   │   │
│  │ Pages       │     │   ├──────────────────────────────┤   │
│  ├─────────────┤     │   │  Tenant Middleware            │   │
│  │ Auth Pages  │◄────┼───│  (multi-tenant isolation)    │   │
│  │ (Clerk)     │     │   ├──────────────────────────────┤   │
│  ├─────────────┤     │   │  RBAC Guards + Entitlements  │   │
│  │ Dashboard   │     │   ├──────────────────────────────┤   │
│  ├─────────────┤     │   │  Feature Modules:            │   │
│  │ ISMS App    │     │   │  - Users & Tenants           │   │
│  ├─────────────┤     │   │  - Billing (Stripe)          │   │
│  │ ZuCards App │     │   │  - ISMS Trustee              │   │
│  ├─────────────┤     │   │  - ZuCards                   │   │
│  │ ZuDoc App   │     │   │  - ZuDoc                     │   │
│  └─────────────┘     │   │  - Notifications (Resend)    │   │
│                      │   └──────────────────────────────┘   │
└──────────────────────┴──────────────────────────────────────┘
         │                            │
         ▼                            ▼
  ┌─────────────┐           ┌──────────────────┐
  │    Clerk    │           │  Supabase (PG)   │
  │   (Auth)    │           │  Supabase Storage│
  └─────────────┘           └──────────────────┘
```

## Multi-Tenant Data Isolation

Every database entity includes a `tenantId` column. The `TenantMiddleware`
resolves the tenant on every authenticated request and sets `req.tenantId`.
All service methods receive and filter by `tenantId`.

Supabase Row Level Security adds a second layer of defence at the database level.

## Module Registration Pattern

New applications can be added without modifying core platform code:

1. Create a NestJS module in `backend/src/modules/<app-name>/`
2. Register the module in `app.module.ts`
3. Add entitlement rows to `application_entitlements` table
4. Add feature flags to `feature_flags` table
5. Create frontend pages in `frontend/src/app/apps/<app-name>/`
6. Add navigation items to the sidebar config

The platform's `EntitlementGuard` automatically enforces plan-based access
without any changes to existing code.

## Subscription & Entitlement Flow

```
User Request → JwtAuthGuard → TenantMiddleware → EntitlementGuard
                                    │                    │
                              Resolves tenant      Checks billing DB:
                              from JWT claim       plan → app entitlement
                                    │                    │
                              Sets req.tenant      Allows/denies
```

## Security Layers

1. **Transport**: HTTPS everywhere, HSTS headers via Vercel/Railway
2. **Authentication**: Clerk handles sessions; backend validates JWTs
3. **Authorisation**: RBAC via `RolesGuard`, app access via `EntitlementGuard`
4. **Data isolation**: Tenant scoping in every query + Supabase RLS
5. **Rate limiting**: NestJS ThrottlerModule with tiered limits
6. **Headers**: Helmet.js sets security headers on all responses
7. **Input validation**: class-validator DTOs on all endpoints
8. **CORS**: Configured to frontend URL only

## Key Design Decisions

### Why Clerk for Auth?
- Eliminates auth complexity (OAuth, email/password, MFA all pre-built)
- Webhook-based sync keeps the platform DB in sync
- SSO-ready for enterprise customers

### Why Supabase?
- Managed PostgreSQL with generous free tier
- Built-in Row Level Security for tenant isolation
- Integrated file storage for documents and evidence
- Realtime subscriptions available for future features

### Why separate frontend and backend?
- Independent scaling and deployment
- Frontend can be a static CDN (Vercel) for performance
- Backend can be horizontally scaled independently
- Cleaner separation of concerns for team development

### Module architecture
Each application (ISMS, ZuCards, ZuDoc) is a self-contained NestJS module
with its own: entities, service, controller, DTOs. This pattern makes adding
the CRM, HR, Finance, and other planned modules trivial.
